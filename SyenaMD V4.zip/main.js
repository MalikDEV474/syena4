const a0_0x367cc1 = a0_0x42a4;
(function (_0x3bd656, _0x59b8d9) {
    const _0x142666 = a0_0x42a4, _0x48a43f = _0x3bd656();
    while (!![]) {
        try {
            const _0xb20d51 = -parseInt(_0x142666(0x15a)) / (-0x1b64 + 0x6 * -0x245 + 0x2903 * 0x1) + parseInt(_0x142666(0x147)) / (0xe26 + 0x133d + -0x6ad * 0x5) + -parseInt(_0x142666(0x1bf)) / (0x13b0 + -0xcb9 + -0x6f4) * (parseInt(_0x142666(0x11c)) / (0x1 * -0x83a + 0x60b + 0x233 * 0x1)) + parseInt(_0x142666(0x132)) / (-0x521 * -0x2 + -0x7 * 0x3e1 + 0x10ea) * (-parseInt(_0x142666(0x182)) / (0x402 + -0xdc + -0x320)) + -parseInt(_0x142666(0x1d4)) / (-0x130 * 0x15 + -0x1c7f + 0x8e9 * 0x6) + -parseInt(_0x142666(0x1db)) / (-0x1ed7 + 0x21ad + -0x2ce) + parseInt(_0x142666(0x198)) / (0x35 * 0x59 + 0x32 * -0x61 + 0x1 * 0x8e);
            if (_0xb20d51 === _0x59b8d9)
                break;
            else
                _0x48a43f['push'](_0x48a43f['shift']());
        } catch (_0xe119cd) {
            _0x48a43f['push'](_0x48a43f['shift']());
        }
    }
}(a0_0x4c3b, 0x201ad + 0x4b1f * 0x5 + 0x9180b), require(a0_0x367cc1(0x163) + a0_0x367cc1(0x180)));
function a0_0x4c3b() {
    const _0x26b818 = [
        'fatal',
        'requestPai',
        'rface',
        'e\x20Session\x20',
        'IAvCq',
        'Replaced',
        '20.0.04',
        '\x20lost,\x20try',
        'ception',
        'bArGI',
        'Menghubung',
        'onfig.js',
        'secret_LiQ',
        '6cOZVQe',
        'aileys',
        'ged\x20Out,\x20P',
        'gain',
        'rnqAJ',
        'p!\x20[\x20',
        'evwAV',
        'green',
        'zHQSi',
        'pSFwI',
        './public/h',
        'ner.json',
        'node-cache',
        'Your\x20Pairi',
        'creds.upda',
        'sendMessag',
        'timedOut',
        'rKoaO',
        'ease\x20Delet',
        '\x20Again\x20And',
        'TBwoK',
        'quired,\x20Re',
        '24517926fySBIG',
        'ot/push/se',
        'convertapi',
        'Chrome',
        'ng\x20Code:\x20',
        'BwdwF',
        'qrVJF',
        'magic-byte',
        '.update',
        'Image',
        'Hallo\x20@',
        'exit',
        'writeFileS',
        'silent',
        'starting..',
        'lease\x20Clos',
        'RwgXw',
        '\x20Opened,\x20P',
        'ot/push/ma',
        'readdir',
        'Bad\x20Sessio',
        's.js',
        '\x20Another\x20N',
        'ess',
        'Session\x20Fi',
        'uired',
        'and\x20Scan\x20A',
        'question',
        'jejqC',
        'ing\x20to\x20rec',
        'yFNlg',
        'forEach',
        'Caught\x20exc',
        'sclih',
        '@hapi/boom',
        'util',
        'process',
        'moment-tim',
        'chalk',
        '951uaWhWK',
        'e\x20Current\x20',
        'Connected\x20',
        'restartReq',
        'jid',
        'oBiya',
        'NmOYI',
        'qxCVb',
        'XSSud',
        'fluent-ffm',
        'error',
        'PtDDC',
        'm/scraper',
        'readline',
        'path',
        'akan\x20seger',
        'Restart\x20Re',
        'kan!.',
        'connecting',
        'JVcId',
        'loggedOut',
        '3105347MiwEkj',
        'WQdzs',
        'ringCode',
        'psert',
        'in.js',
        'dHMCj',
        'IpBOq',
        '11038520pQjnXr',
        'Connection',
        '\x20anda',
        'pdate',
        'rst',
        'Device\x20Log',
        'AsEyY',
        'hFcta',
        'ytdl-core',
        'age.js',
        'Closed',
        'sfYRA',
        'isTvY',
        'store',
        'google-tts',
        'stringify',
        '1052HkSXab',
        'wERVw',
        'RteDW',
        'ing...',
        'yqmrS',
        'YzObv',
        'atabase/ow',
        'lAjTI',
        'node-webpm',
        'connection',
        'JvmSX',
        'econnectin',
        'bOvhY',
        'user',
        'onnect',
        'stdout',
        'output',
        'cheerio',
        'Mzk2fnLaW3',
        'api-dylux',
        'ezone',
        'eption:\x20',
        '6352165xdVmRU',
        './session/',
        'stdin',
        'a\x20di\x20aktif',
        'peg',
        'registered',
        '\x20Replaced,',
        'jimp',
        'pino',
        'open',
        'Wcwqq',
        'Ubuntu',
        'createInte',
        '\x20TimedOut,',
        'ync',
        'ggLdZ',
        'ew\x20Session',
        './public/b',
        'mWXas',
        'g...',
        'tmvAY',
        '3028694ZjQyqn',
        'group-part',
        '\x20Bot\x20anda\x20',
        'lease\x20Scan',
        'log',
        'axios',
        'form-data',
        'child_proc',
        'kan...',
        'Masukan\x20no',
        'andle/grou',
        'andle/mess',
        'uncaughtEx',
        'trim',
        '-api',
        'messages.u',
        'Lost',
        '\x20Run.',
        'close',
        '237686ecIrfy',
        'ssion/',
        'https',
        'authState',
        'JbUkM',
        './public/d',
        'jifRZ',
        'n\x20File,\x20Pl',
        'ZLiTo',
        './public/c',
        'mor\x20telpon',
        'to\x20WhatsAp',
        'p.js',
        'mof',
        'creds',
        '@seaavey/b',
        'badSession',
        'child',
        'dSEap',
        '\x20Reconnect',
        '-->\x20',
        '@bochiltea',
        'split',
        'statusCode',
        '\x20closed,\x20r',
        'icipants.u',
        'yt-search'
    ];
    a0_0x4c3b = function () {
        return _0x26b818;
    };
    return a0_0x4c3b();
}
const {jidDecode, DisconnectReason, makeInMemoryStore, makeWASocket, makeCacheableSignalKeyStore, fetchLatestBaileysVersion, useMultiFileAuthState, getContentType, downloadContentFromMessage, generateWAMessageContent, prepareWAMessageMedia, generateWAMessageFromContent, proto} = require(a0_0x367cc1(0x169) + a0_0x367cc1(0x183)), {exec, spawn, execSync} = require(a0_0x367cc1(0x14e) + a0_0x367cc1(0x1af));
function a0_0x42a4(_0x1aaf5a, _0x19bb9c) {
    const _0x90a672 = a0_0x4c3b();
    return a0_0x42a4 = function (_0xc986e4, _0x466c8a) {
        _0xc986e4 = _0xc986e4 - (0xa * 0x1fd + -0x17f3 * 0x1 + -0x3 * -0x1b7);
        let _0x23ca82 = _0x90a672[_0xc986e4];
        return _0x23ca82;
    }, a0_0x42a4(_0x1aaf5a, _0x19bb9c);
}
let NodeCache = require(a0_0x367cc1(0x18e));
const msgRetryCounterCache = new NodeCache(), boom = require(a0_0x367cc1(0x1ba)), ytdl = require(a0_0x367cc1(0x114)), https = require(a0_0x367cc1(0x15c)), fs = require('fs'), axios = require(a0_0x367cc1(0x14c)), readline = require(a0_0x367cc1(0x1cc)), cheerio = require(a0_0x367cc1(0x12d)), webp = require(a0_0x367cc1(0x124) + 'ux'), img = new webp[(a0_0x367cc1(0x1a1))](), ffmpeg = require(a0_0x367cc1(0x1c8) + a0_0x367cc1(0x136)), convertapi = require(a0_0x367cc1(0x19a))(a0_0x367cc1(0x181) + a0_0x367cc1(0x12e) + a0_0x367cc1(0x167)), moment = require(a0_0x367cc1(0x1bd) + a0_0x367cc1(0x130)), FormData = require(a0_0x367cc1(0x14d)), os = require('os'), path = require(a0_0x367cc1(0x1cd)), chalk = require(a0_0x367cc1(0x1be)), pino = require(a0_0x367cc1(0x13a)), util = require(a0_0x367cc1(0x1bb)), tts = require(a0_0x367cc1(0x11a) + a0_0x367cc1(0x155)), api = require(a0_0x367cc1(0x12f)), yts = require(a0_0x367cc1(0x174)), magic = require(a0_0x367cc1(0x19f) + a0_0x367cc1(0x1ad)), Jimp = require(a0_0x367cc1(0x139)), scraper = require(a0_0x367cc1(0x16f) + a0_0x367cc1(0x1cb)), process = require(a0_0x367cc1(0x1bc)), question = _0x3d1229 => {
        const _0xbced8b = a0_0x367cc1, _0x172612 = readline[_0xbced8b(0x13e) + _0xbced8b(0x177)]({
                'input': process[_0xbced8b(0x134)],
                'output': process[_0xbced8b(0x12b)]
            });
        return new Promise(_0x2edb18 => {
            const _0x4b41b = _0xbced8b;
            _0x172612[_0x4b41b(0x1b3)](_0x3d1229, _0x2edb18);
        });
    };
async function connect() {
    const _0x4606cc = a0_0x367cc1, _0x4fe7f5 = {
            'evwAV': function (_0x2a8665, _0xe64f84, _0x52dcff, _0x538beb) {
                return _0x2a8665(_0xe64f84, _0x52dcff, _0x538beb);
            },
            'rKoaO': function (_0x2360f5, _0x4f1801) {
                return _0x2360f5 === _0x4f1801;
            },
            'jejqC': _0x4606cc(0x159),
            'wERVw': function (_0x65baa5, _0x1bced7) {
                return _0x65baa5 === _0x1bced7;
            },
            'PtDDC': _0x4606cc(0x1ac) + _0x4606cc(0x161) + _0x4606cc(0x194) + _0x4606cc(0x178) + _0x4606cc(0x1b2) + _0x4606cc(0x185),
            'JVcId': function (_0x55e369, _0x295b9e) {
                return _0x55e369 === _0x295b9e;
            },
            'YzObv': _0x4606cc(0x1dc) + _0x4606cc(0x172) + _0x4606cc(0x127) + _0x4606cc(0x145),
            'tmvAY': function (_0x4ad5f1) {
                return _0x4ad5f1();
            },
            'ggLdZ': function (_0x4fc0c5, _0x4592aa) {
                return _0x4fc0c5 === _0x4592aa;
            },
            'dSEap': _0x4606cc(0x1dc) + _0x4606cc(0x17c) + _0x4606cc(0x1b5) + _0x4606cc(0x12a),
            'RwgXw': function (_0x1f7c5e) {
                return _0x1f7c5e();
            },
            'sfYRA': _0x4606cc(0x1dc) + _0x4606cc(0x138) + _0x4606cc(0x1ae) + _0x4606cc(0x142) + _0x4606cc(0x1a9) + _0x4606cc(0x1a7) + _0x4606cc(0x1c0) + _0x4606cc(0x1b0) + _0x4606cc(0x1df),
            'hFcta': _0x4606cc(0x1e0) + _0x4606cc(0x184) + _0x4606cc(0x14a) + _0x4606cc(0x195) + _0x4606cc(0x158),
            'AsEyY': _0x4606cc(0x1cf) + _0x4606cc(0x197) + _0x4606cc(0x1a6) + '.',
            'NmOYI': function (_0x5598f9) {
                return _0x5598f9();
            },
            'dHMCj': _0x4606cc(0x1dc) + _0x4606cc(0x13f) + _0x4606cc(0x16d) + _0x4606cc(0x11f),
            'XSSud': function (_0x91abb9) {
                return _0x91abb9();
            },
            'bOvhY': function (_0x10fb55, _0x2099be) {
                return _0x10fb55 === _0x2099be;
            },
            'WQdzs': _0x4606cc(0x1d1),
            'rnqAJ': _0x4606cc(0x17f) + _0x4606cc(0x14f),
            'oBiya': function (_0x3ac784, _0x25a403) {
                return _0x3ac784 === _0x25a403;
            },
            'sclih': _0x4606cc(0x13b),
            'mWXas': function (_0x34b464, _0x13fde0) {
                return _0x34b464(_0x13fde0);
            },
            'jifRZ': _0x4606cc(0x143) + _0x4606cc(0x1aa) + _0x4606cc(0x1d8),
            'JvmSX': _0x4606cc(0x143) + _0x4606cc(0x199) + _0x4606cc(0x15b),
            'IAvCq': _0x4606cc(0x15f) + _0x4606cc(0x122) + _0x4606cc(0x18d),
            'qxCVb': _0x4606cc(0x1a5),
            'IpBOq': _0x4606cc(0x119),
            'pSFwI': _0x4606cc(0x175),
            'lAjTI': _0x4606cc(0x13d),
            'bArGI': _0x4606cc(0x19b),
            'qrVJF': _0x4606cc(0x17b),
            'yqmrS': _0x4606cc(0x150) + _0x4606cc(0x164) + _0x4606cc(0x1dd),
            'zHQSi': function (_0x32fca6, _0x1064a6) {
                return _0x32fca6(_0x1064a6);
            },
            'JbUkM': _0x4606cc(0x16e),
            'TBwoK': _0x4606cc(0x125) + _0x4606cc(0x1a0),
            'isTvY': _0x4606cc(0x190) + 'te',
            'Wcwqq': _0x4606cc(0x156) + _0x4606cc(0x1d7),
            'BwdwF': _0x4606cc(0x148) + _0x4606cc(0x173) + _0x4606cc(0x1de)
        }, _0x45fc8e = _0x4fe7f5[_0x4606cc(0x144)](makeInMemoryStore, {
            'logger': _0x4fe7f5[_0x4606cc(0x1c7)](pino)[_0x4606cc(0x16b)]({
                'level': _0x4fe7f5[_0x4606cc(0x1c6)],
                'stream': _0x4fe7f5[_0x4606cc(0x1da)]
            })
        }), {
            state: _0x664c36,
            saveCreds: _0x59f253
        } = await _0x4fe7f5[_0x4606cc(0x144)](useMultiFileAuthState, _0x4606cc(0x133)), {
            version: _0x17847e,
            isLatest: _0x16ae42
        } = await _0x4fe7f5[_0x4606cc(0x1c7)](fetchLatestBaileysVersion), _0x41589d = _0x4fe7f5[_0x4606cc(0x144)](makeWASocket, {
            'version': [
                0x1 * -0x200c + -0x1c91 + 0x3c9f,
                -0xe31 + -0x2 * -0xc7d + 0xef,
                -0x1b2c2339 + 0x482 * -0x168b26 + 0xbd58d100
            ],
            'keepAliveIntervalMs': 0x7530,
            'printQRInTerminal': ![],
            'logger': _0x4fe7f5[_0x4606cc(0x144)](pino, { 'level': _0x4fe7f5[_0x4606cc(0x18b)] }),
            'auth': _0x664c36,
            'browser': [
                _0x4fe7f5[_0x4606cc(0x123)],
                _0x4fe7f5[_0x4606cc(0x17e)],
                _0x4fe7f5[_0x4606cc(0x19e)]
            ]
        });
    if (!_0x41589d[_0x4606cc(0x15d)][_0x4606cc(0x168)][_0x4606cc(0x137)]) {
        console[_0x4606cc(0x14b)](chalk[_0x4606cc(0x189)](_0x4fe7f5[_0x4606cc(0x120)]));
        const _0x253df1 = await _0x4fe7f5[_0x4606cc(0x18a)](question, _0x4fe7f5[_0x4606cc(0x15e)]), _0x1255d0 = await _0x41589d[_0x4606cc(0x176) + _0x4606cc(0x1d6)](_0x253df1[_0x4606cc(0x154)]());
        console[_0x4606cc(0x14b)](_0x4606cc(0x18f) + _0x4606cc(0x19c) + _0x1255d0);
    }
    return _0x41589d['ev']['on'](_0x4fe7f5[_0x4606cc(0x196)], async _0x365e7a => {
        const _0x181b88 = _0x4606cc, _0x2834f7 = {
                'RteDW': function (_0x1f2e2a, _0x1935ef, _0x376f01, _0x42d44b) {
                    const _0x40af24 = a0_0x42a4;
                    return _0x4fe7f5[_0x40af24(0x188)](_0x1f2e2a, _0x1935ef, _0x376f01, _0x42d44b);
                }
            }, {
                connection: _0x5c4b67,
                lastDisconnect: _0x1f41c7
            } = _0x365e7a;
        if (_0x4fe7f5[_0x181b88(0x193)](_0x5c4b67, _0x4fe7f5[_0x181b88(0x1b4)])) {
            const _0x140f79 = _0x1f41c7?.[_0x181b88(0x1c9)]?.[_0x181b88(0x12c)]?.[_0x181b88(0x171)];
            console[_0x181b88(0x14b)](_0x1f41c7?.[_0x181b88(0x1c9)]);
            if (_0x4fe7f5[_0x181b88(0x11d)](_0x140f79, DisconnectReason[_0x181b88(0x16a)]))
                console[_0x181b88(0x14b)](_0x4fe7f5[_0x181b88(0x1ca)]), process[_0x181b88(0x1a3)]();
            else {
                if (_0x4fe7f5[_0x181b88(0x1d2)](_0x140f79, DisconnectReason[_0x181b88(0x125) + _0x181b88(0x116)]))
                    console[_0x181b88(0x14b)](_0x4fe7f5[_0x181b88(0x121)]), _0x4fe7f5[_0x181b88(0x146)](connect);
                else {
                    if (_0x4fe7f5[_0x181b88(0x141)](_0x140f79, DisconnectReason[_0x181b88(0x125) + _0x181b88(0x157)]))
                        console[_0x181b88(0x14b)](_0x4fe7f5[_0x181b88(0x16c)]), _0x4fe7f5[_0x181b88(0x1a8)](connect);
                    else {
                        if (_0x4fe7f5[_0x181b88(0x141)](_0x140f79, DisconnectReason[_0x181b88(0x125) + _0x181b88(0x17a)]))
                            console[_0x181b88(0x14b)](_0x4fe7f5[_0x181b88(0x117)]), process[_0x181b88(0x1a3)]();
                        else {
                            if (_0x4fe7f5[_0x181b88(0x141)](_0x140f79, DisconnectReason[_0x181b88(0x1d3)]))
                                console[_0x181b88(0x14b)](_0x4fe7f5[_0x181b88(0x1e2)]), process[_0x181b88(0x1a3)]();
                            else {
                                if (_0x4fe7f5[_0x181b88(0x193)](_0x140f79, DisconnectReason[_0x181b88(0x1c2) + _0x181b88(0x1b1)]))
                                    console[_0x181b88(0x14b)](_0x4fe7f5[_0x181b88(0x1e1)]), await _0x4fe7f5[_0x181b88(0x1c5)](connect);
                                else
                                    _0x4fe7f5[_0x181b88(0x141)](_0x140f79, DisconnectReason[_0x181b88(0x192)]) && (console[_0x181b88(0x14b)](_0x4fe7f5[_0x181b88(0x1d9)]), _0x4fe7f5[_0x181b88(0x1c7)](connect));
                            }
                        }
                    }
                }
            }
        } else {
            if (_0x4fe7f5[_0x181b88(0x128)](_0x5c4b67, _0x4fe7f5[_0x181b88(0x1d5)]))
                console[_0x181b88(0x14b)](_0x4fe7f5[_0x181b88(0x186)]);
            else {
                if (_0x4fe7f5[_0x181b88(0x1c4)](_0x5c4b67, _0x4fe7f5[_0x181b88(0x1b9)])) {
                    let {
                        user: _0x3e7979,
                        server: _0x11cc3a
                    } = _0x4fe7f5[_0x181b88(0x144)](jidDecode, _0x41589d[_0x181b88(0x129)]['id']);
                    const {jadibot: _0x16b077} = _0x4fe7f5[_0x181b88(0x144)](require, _0x4fe7f5[_0x181b88(0x160)]);
                    fs[_0x181b88(0x1ab)](_0x4fe7f5[_0x181b88(0x126)], (_0x1dc15a, _0x1144be) => {
                        const _0x3878de = _0x181b88, _0x1ca224 = {
                                'yFNlg': function (_0x276473, _0x2f397b, _0x17e52c, _0x72f550) {
                                    const _0x1727b6 = a0_0x42a4;
                                    return _0x2834f7[_0x1727b6(0x11e)](_0x276473, _0x2f397b, _0x17e52c, _0x72f550);
                                }
                            };
                        !_0x1dc15a && _0x1144be[_0x3878de(0x1b7)](_0x9f498f => {
                            const _0x5a2ec2 = _0x3878de;
                            let _0x3bb2b7 = _0x5a2ec2(0x1a2) + _0x9f498f[_0x5a2ec2(0x170)]('@')[-0xb * 0x2fe + -0xf62 + -0x304c * -0x1] + (_0x5a2ec2(0x149) + _0x5a2ec2(0x1ce) + _0x5a2ec2(0x135) + _0x5a2ec2(0x1d0)), _0x337730 = _0x41589d[_0x5a2ec2(0x191) + 'e'](_0x9f498f, {
                                    'text': _0x3bb2b7,
                                    'mentions': [_0x9f498f]
                                });
                            _0x1ca224[_0x5a2ec2(0x1b6)](_0x16b077, _0x41589d, _0x9f498f, _0x337730);
                        });
                    }), _0x41589d[_0x181b88(0x129)][_0x181b88(0x1c3)] = _0x3e7979 + '@' + _0x11cc3a, fs[_0x181b88(0x1a4) + _0x181b88(0x140)](_0x4fe7f5[_0x181b88(0x179)], JSON[_0x181b88(0x11b)]([_0x41589d[_0x181b88(0x129)][_0x181b88(0x1c3)]])), console[_0x181b88(0x14b)](chalk[_0x181b88(0x189)](_0x181b88(0x1c1) + _0x181b88(0x165) + _0x181b88(0x187) + _0x3e7979 + '\x20]'));
                }
            }
        }
    }), _0x41589d['ev']['on'](_0x4fe7f5[_0x4606cc(0x118)], _0x59f253), _0x41589d['ev']['on'](_0x4fe7f5[_0x4606cc(0x13c)], _0x477f26 => require(_0x4606cc(0x18c) + _0x4606cc(0x152) + _0x4606cc(0x115))(_0x41589d, _0x477f26, _0x45fc8e)), _0x41589d['ev']['on'](_0x4fe7f5[_0x4606cc(0x19d)], async _0x1a6b81 => require(_0x4606cc(0x18c) + _0x4606cc(0x151) + _0x4606cc(0x166))(_0x41589d, _0x1a6b81)), _0x41589d;
}
connect(), process['on'](a0_0x367cc1(0x153) + a0_0x367cc1(0x17d), function (_0x56af82) {
    const _0x1887d8 = a0_0x367cc1, _0x243f7b = { 'ZLiTo': _0x1887d8(0x1b8) + _0x1887d8(0x131) };
    console[_0x1887d8(0x14b)](_0x243f7b[_0x1887d8(0x162)], _0x56af82);
});