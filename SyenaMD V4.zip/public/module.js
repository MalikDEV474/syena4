const a0_0x4b55f1 = a0_0xc181;
(function (_0x357449, _0x43d318) {
    const _0x2e87e9 = a0_0xc181, _0x51837e = _0x357449();
    while (!![]) {
        try {
            const _0x36ed6b = parseInt(_0x2e87e9(0x1fe)) / (-0x76d + -0x3 * -0x860 + 0xa * -0x1c5) * (-parseInt(_0x2e87e9(0x1e5)) / (0x1ba0 + 0xf04 + -0x2aa2)) + -parseInt(_0x2e87e9(0x1db)) / (0x15c * -0x1 + -0x23 * -0x31 + -0x3e * 0x16) * (parseInt(_0x2e87e9(0x1f8)) / (0x2198 + -0x1c9d + -0x4f7)) + parseInt(_0x2e87e9(0x1cf)) / (-0xae2 + -0x4c * 0x4d + 0x21c3) * (-parseInt(_0x2e87e9(0x1de)) / (0x23e0 + -0x80a + -0x28 * 0xb2)) + -parseInt(_0x2e87e9(0x1f2)) / (0x1182 + -0x32f + -0xe4c) + -parseInt(_0x2e87e9(0x1d7)) / (0x67f * -0x6 + 0x1299 + 0x1 * 0x1469) * (parseInt(_0x2e87e9(0x1d6)) / (0xbc9 + -0xa3 * -0x20 + 0x2020 * -0x1)) + parseInt(_0x2e87e9(0x1e9)) / (-0x1b79 + -0x115 * -0x2 + -0x1 * -0x1959) + -parseInt(_0x2e87e9(0x200)) / (-0x1556 + -0x101 * -0x14 + 0x14d) * (-parseInt(_0x2e87e9(0x1ed)) / (-0x18 * -0xcc + 0x4 * 0x42c + -0x23c4));
            if (_0x36ed6b === _0x43d318)
                break;
            else
                _0x51837e['push'](_0x51837e['shift']());
        } catch (_0x30c929) {
            _0x51837e['push'](_0x51837e['shift']());
        }
    }
}(a0_0x446b, 0x1 * 0x1cb0b + -0x6c13 * -0x28 + -0x1 * 0x5b59b));
const {jidDecode, DisconnectReason, makeInMemoryStore, makeWASocket, makeCacheableSignalKeyStore, fetchLatestBaileysVersion, useMultiFileAuthState, getContentType, downloadContentFromMessage, generateWAMessageContent, prepareWAMessageMedia, generateWAMessageFromContent, proto} = require(a0_0x4b55f1(0x1d2) + a0_0x4b55f1(0x204) + a0_0x4b55f1(0x1e6)), {exec, spawn, execSync} = require(a0_0x4b55f1(0x1e0) + a0_0x4b55f1(0x1f3));
function a0_0xc181(_0x4c939f, _0x56b01b) {
    const _0x62d93a = a0_0x446b();
    return a0_0xc181 = function (_0x1ebd24, _0x439dcb) {
        _0x1ebd24 = _0x1ebd24 - (-0xbd * 0xe + 0x1 * -0x33b + 0xf5f * 0x1);
        let _0x59f68f = _0x62d93a[_0x1ebd24];
        return _0x59f68f;
    }, a0_0xc181(_0x4c939f, _0x56b01b);
}
function a0_0x446b() {
    const _0x38c542 = [
        'path',
        '@hapi/boom',
        'process',
        '11264gNtyBL',
        'watchFile',
        'axios',
        'secret_LiQ',
        'm/scraper',
        'google-tts',
        '943512ASIKdC',
        'mof',
        '1220109sxJmwQ',
        'Mzk2fnLaW3',
        'chalk',
        'api-dylux',
        'ckets/bail',
        '@bochiltea',
        '689995ahBAih',
        '-api',
        'peg',
        '@whiskeyso',
        'form-data',
        'resolve',
        'node-webpm',
        '261639uOnGuF',
        '16zcbMeF',
        'Image',
        './ytdl',
        'magic-byte',
        '1194WJnBAY',
        'convertapi',
        'node-cache',
        '72IKIYhM',
        'fluent-ffm',
        'child_proc',
        'https',
        'unwatchFil',
        'cheerio',
        'cache',
        '2yPtWci',
        'eys',
        'yt-search',
        'ezone',
        '4406260PtHBJl',
        'pino',
        'util',
        'readline',
        '612sUXSlB',
        'moment-tim',
        'utbHF',
        's.js',
        'jimp',
        '10283427RAMOXp',
        'ess',
        'ytdl-core'
    ];
    a0_0x446b = function () {
        return _0x38c542;
    };
    return a0_0x446b();
}
let NodeCache = require(a0_0x4b55f1(0x1dd));
const msgRetryCounterCache = new NodeCache(), boom = require(a0_0x4b55f1(0x1f6)), yt = require(a0_0x4b55f1(0x1d9)), ytdl = require(a0_0x4b55f1(0x1f4)), https = require(a0_0x4b55f1(0x1e1)), fs = require('fs'), axios = require(a0_0x4b55f1(0x1fa)), readline = require(a0_0x4b55f1(0x1ec)), cheerio = require(a0_0x4b55f1(0x1e3)), webp = require(a0_0x4b55f1(0x1d5) + 'ux'), img = new webp[(a0_0x4b55f1(0x1d8))](), ffmpeg = require(a0_0x4b55f1(0x1df) + a0_0x4b55f1(0x1d1)), convertapi = require(a0_0x4b55f1(0x1dc))(a0_0x4b55f1(0x1fb) + a0_0x4b55f1(0x201) + a0_0x4b55f1(0x1ff)), moment = require(a0_0x4b55f1(0x1ee) + a0_0x4b55f1(0x1e8)), FormData = require(a0_0x4b55f1(0x1d3)), os = require('os'), path = require(a0_0x4b55f1(0x1f5)), chalk = require(a0_0x4b55f1(0x202)), pino = require(a0_0x4b55f1(0x1ea)), util = require(a0_0x4b55f1(0x1eb)), tts = require(a0_0x4b55f1(0x1fd) + a0_0x4b55f1(0x1d0)), api = require(a0_0x4b55f1(0x203)), yts = require(a0_0x4b55f1(0x1e7)), magic = require(a0_0x4b55f1(0x1da) + a0_0x4b55f1(0x1f0)), Jimp = require(a0_0x4b55f1(0x1f1)), scraper = require(a0_0x4b55f1(0x1ce) + a0_0x4b55f1(0x1fc)), process = require(a0_0x4b55f1(0x1f7));
let file = require[a0_0x4b55f1(0x1d4)](__filename);
fs[a0_0x4b55f1(0x1f9)](file, () => {
    const _0x219f10 = a0_0x4b55f1, _0x218550 = {
            'utbHF': function (_0x20d43c, _0xdecf9c) {
                return _0x20d43c(_0xdecf9c);
            }
        };
    fs[_0x219f10(0x1e2) + 'e'](file), delete require[_0x219f10(0x1e4)][file], _0x218550[_0x219f10(0x1ef)](require, file);
});