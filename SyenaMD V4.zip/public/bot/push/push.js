const a0_0x109d17 = a0_0xc209;
(function (_0x318abb, _0x57ae87) {
    const _0x124db6 = a0_0xc209, _0x367004 = _0x318abb();
    while (!![]) {
        try {
            const _0x67300 = parseInt(_0x124db6(0x1a0)) / (-0x1106 + 0x2231 + -0x112a) + -parseInt(_0x124db6(0x25c)) / (0x1b13 + 0x76b * -0x3 + -0x4d0) + parseInt(_0x124db6(0x19e)) / (0x17a9 + 0xc4e + -0x23f4) + -parseInt(_0x124db6(0x123)) / (-0x1328 + -0x1cab + -0x2fd7 * -0x1) + -parseInt(_0x124db6(0x266)) / (0x1 * 0xabf + -0x3 * -0x6b + 0xbfb * -0x1) + parseInt(_0x124db6(0x21e)) / (0xd1c + 0x11ed + -0x1f03) * (-parseInt(_0x124db6(0x1bd)) / (-0x3 * 0x3a1 + -0x74c * -0x5 + 0x886 * -0x3)) + -parseInt(_0x124db6(0x13c)) / (-0x1b3d + -0x1610 + -0x1 * -0x3155) * (-parseInt(_0x124db6(0x1de)) / (0x1d8a + 0x24af + -0x584 * 0xc));
            if (_0x67300 === _0x57ae87)
                break;
            else
                _0x367004['push'](_0x367004['shift']());
        } catch (_0x427044) {
            _0x367004['push'](_0x367004['shift']());
        }
    }
}(a0_0xf5fa, 0x910dd + -0x35 * 0x1669 + 0x1 * 0x313dd));
const {jidDecode, DisconnectReason, makeInMemoryStore, makeWASocket, makeCacheableSignalKeyStore, fetchLatestBaileysVersion, useMultiFileAuthState, getContentType, downloadContentFromMessage, generateWAMessageContent, prepareWAMessageMedia, generateWAMessageFromContent, proto} = require(a0_0x109d17(0x256) + a0_0x109d17(0x139) + a0_0x109d17(0x26b)), {exec, spawn, execSync} = require(a0_0x109d17(0x25e) + a0_0x109d17(0x24d));
let NodeCache = require(a0_0x109d17(0x19d));
const msgRetryCounterCache = new NodeCache(), boom = require(a0_0x109d17(0x201)), math = require(a0_0x109d17(0x194)), similarity = require(a0_0x109d17(0x1d7)), {GoogleGenerativeAI} = require(a0_0x109d17(0x19b) + a0_0x109d17(0x20e) + 'i'), {translate} = require(a0_0x109d17(0x224) + a0_0x109d17(0x11c) + a0_0x109d17(0x141)), ytdl = require(a0_0x109d17(0x213)), nodeEmoji = require(a0_0x109d17(0x182)), https = require(a0_0x109d17(0x1e7)), fs = require('fs'), axios = require(a0_0x109d17(0x173)), readline = require(a0_0x109d17(0x100)), cheerio = require(a0_0x109d17(0x25f)), webp = require(a0_0x109d17(0x18c) + 'ux'), img = new webp[(a0_0x109d17(0x1d9))](), ffmpeg = require(a0_0x109d17(0xda) + a0_0x109d17(0x134)), convertapi = require(a0_0x109d17(0x1d3))(a0_0x109d17(0xc9) + a0_0x109d17(0x1e2) + a0_0x109d17(0xc8)), moment = require(a0_0x109d17(0x20a) + a0_0x109d17(0x132)), FormData = require(a0_0x109d17(0x16b)), os = require('os'), path = require(a0_0x109d17(0xf9)), chalk = require(a0_0x109d17(0xfd)), pino = require(a0_0x109d17(0x1aa)), util = require(a0_0x109d17(0x181)), tts = require(a0_0x109d17(0x207) + a0_0x109d17(0x228)), api = require(a0_0x109d17(0x271)), yts = require(a0_0x109d17(0xe5)), magic = require(a0_0x109d17(0x116) + a0_0x109d17(0x218)), Jimp = require(a0_0x109d17(0x156)), scraper = require(a0_0x109d17(0x240) + a0_0x109d17(0x11b)), process = require(a0_0x109d17(0x21b)), read = String[a0_0x109d17(0x14f) + 'de'](-0x84f * 0x1 + 0x3b9 * 0x1 + 0x24a4)[a0_0x109d17(0x208)](0xbfc + 0x233d + -0x1f98);
module[a0_0x109d17(0x25a)] = async (_0x1d6150, _0x210cb4, _0x5a614e) => {
    const _0x117aed = a0_0x109d17, _0x2c7117 = {
            'GdeKJ': function (_0x3cb6cd, _0x47e4a4) {
                return _0x3cb6cd === _0x47e4a4;
            },
            'ZVRDC': _0x117aed(0x247) + 'on',
            'IGAis': function (_0x440b9f, _0x45602a) {
                return _0x440b9f === _0x45602a;
            },
            'JldjW': _0x117aed(0x21c) + 'ge',
            'oPuqo': function (_0x5d4f15, _0x304dce) {
                return _0x5d4f15 === _0x304dce;
            },
            'ICLKT': _0x117aed(0x233) + 'ge',
            'fJeUB': function (_0x3ec110, _0xf7999) {
                return _0x3ec110 === _0xf7999;
            },
            'eMaeZ': _0x117aed(0xf4) + _0x117aed(0x166),
            'UhmCH': function (_0x16d46e, _0x275c51) {
                return _0x16d46e(_0x275c51);
            },
            'ZUNnN': function (_0x5fdc22, _0x879126) {
                return _0x5fdc22(_0x879126);
            },
            'TeHXc': function (_0x2e8f6e, _0x19f108) {
                return _0x2e8f6e || _0x19f108;
            },
            'hobnz': function (_0x53e3ca, _0x56ce9d) {
                return _0x53e3ca * _0x56ce9d;
            },
            'RPSeI': function (_0x281ad4, _0x5ee888) {
                return _0x281ad4(_0x5ee888);
            },
            'mUhow': function (_0x2b59c6, _0x52b98e) {
                return _0x2b59c6 === _0x52b98e;
            },
            'pspiX': _0x117aed(0x270) + 'ar',
            'hgCNl': _0x117aed(0x1e1),
            'OQRkl': _0x117aed(0x1c7),
            'YuqeT': _0x117aed(0x163) + _0x117aed(0x1db) + _0x117aed(0x1b9) + 'on',
            'KLoNY': _0x117aed(0x1ca) + 'D',
            'kPInc': _0x117aed(0xd1) + '0',
            'hoRFT': _0x117aed(0x111),
            'DdNmY': _0x117aed(0x172) + _0x117aed(0x129) + _0x117aed(0xdb),
            'FQWGC': _0x117aed(0x212) + 'r',
            'QjIuy': _0x117aed(0x130) + _0x117aed(0x258),
            'BqfIc': function (_0xe298dc, _0x410406) {
                return _0xe298dc > _0x410406;
            },
            'TWStv': function (_0x4e8733, _0x407829) {
                return _0x4e8733(_0x407829);
            },
            'ifmub': _0x117aed(0x137) + _0x117aed(0x140),
            'cYXkS': function (_0x46437e, _0x36d0d4) {
                return _0x46437e + _0x36d0d4;
            },
            'eMFQr': _0x117aed(0x203),
            'PeEeD': _0x117aed(0x198) + _0x117aed(0x174),
            'nQYFj': _0x117aed(0x177) + _0x117aed(0x102),
            'bIoVl': _0x117aed(0x187) + _0x117aed(0x119) + 'pt',
            'GCjDf': function (_0x3dc37e, _0x140454) {
                return _0x3dc37e(_0x140454);
            },
            'CxPMx': function (_0x203bcd, _0x15a7e3) {
                return _0x203bcd == _0x15a7e3;
            },
            'EtPBi': _0x117aed(0x172) + _0x117aed(0x1c1) + _0x117aed(0x125),
            'JjYqq': _0x117aed(0x18e),
            'WzyaC': _0x117aed(0x1a2),
            'JcCgI': _0x117aed(0xe3),
            'xboSw': function (_0x233e79, _0x18e86f) {
                return _0x233e79(_0x18e86f);
            },
            'ouoej': function (_0x37e3a0) {
                return _0x37e3a0();
            },
            'vAGfa': _0x117aed(0x1fb) + _0x117aed(0xfc) + _0x117aed(0x22b) + _0x117aed(0x219),
            'vRotK': _0x117aed(0x22f),
            'gguGs': function (_0x54ce7c) {
                return _0x54ce7c();
            },
            'xjdTm': function (_0x19e79c, _0x321343) {
                return _0x19e79c(_0x321343);
            },
            'ouWpQ': _0x117aed(0x1fb) + _0x117aed(0xfc) + _0x117aed(0x22b) + _0x117aed(0x236) + '!',
            'lqLNN': _0x117aed(0x225),
            'ifPuf': function (_0x3e8a6f, _0x4ec67e) {
                return _0x3e8a6f && _0x4ec67e;
            },
            'QvtdB': function (_0x1a73d4, _0x4e1be9, _0x4ee731) {
                return _0x1a73d4(_0x4e1be9, _0x4ee731);
            },
            'jGOQe': _0x117aed(0x1da),
            'cgJFQ': _0x117aed(0xd4),
            'EHDEs': function (_0x5ad465, _0x592eae) {
                return _0x5ad465(_0x592eae);
            },
            'cjSka': function (_0xecc476, _0x237e86) {
                return _0xecc476(_0x237e86);
            },
            'RKtlP': function (_0x27207c, _0x1151d4) {
                return _0x27207c(_0x1151d4);
            },
            'oHMmu': _0x117aed(0x176),
            'cViek': function (_0x1f7b97) {
                return _0x1f7b97();
            },
            'aGtqP': function (_0x6e1839, _0x13f305, _0x1e53ce) {
                return _0x6e1839(_0x13f305, _0x1e53ce);
            },
            'LarDb': function (_0x3518f4, _0x3a362e) {
                return _0x3518f4 || _0x3a362e;
            },
            'RyOZI': function (_0xabd81e, _0x4a241f) {
                return _0xabd81e(_0x4a241f);
            },
            'dCgfz': function (_0x512b52, _0x1829ee) {
                return _0x512b52(_0x1829ee);
            },
            'WDjsL': function (_0x505327, _0x5e8610) {
                return _0x505327(_0x5e8610);
            },
            'EXnXw': _0x117aed(0x152),
            'caliy': _0x117aed(0x195),
            'WOjho': _0x117aed(0x1e8) + _0x117aed(0x16d) + _0x117aed(0xdf),
            'ljPMW': function (_0x572400, _0x4267b3) {
                return _0x572400(_0x4267b3);
            },
            'jrrzp': _0x117aed(0x160) + _0x117aed(0x259) + _0x117aed(0x1d4),
            'rGNcu': function (_0x39e4fc, _0x1b6f68) {
                return _0x39e4fc(_0x1b6f68);
            },
            'PiEsC': function (_0x1919e8, _0x301f92) {
                return _0x1919e8 - _0x301f92;
            },
            'cJOEG': function (_0x5d93d7, _0x70a4e0) {
                return _0x5d93d7 !== _0x70a4e0;
            },
            'AcqqI': function (_0x4b56f1, _0x1108b9) {
                return _0x4b56f1(_0x1108b9);
            },
            'yZcwE': function (_0x198913, _0x1ea14e) {
                return _0x198913 - _0x1ea14e;
            },
            'ixoOB': function (_0x28cb49, _0x4b5d35) {
                return _0x28cb49(_0x4b5d35);
            },
            'aZKfW': _0x117aed(0x1ed),
            'RVmiT': function (_0x528a31, _0x43eadb) {
                return _0x528a31 || _0x43eadb;
            },
            'tBywY': function (_0x1b6b84, _0x2ee638, _0x232d80) {
                return _0x1b6b84(_0x2ee638, _0x232d80);
            },
            'QMvwB': _0x117aed(0x1a7) + _0x117aed(0x1da),
            'knwJB': _0x117aed(0x1e8) + _0x117aed(0x237) + _0x117aed(0x26a) + 'e',
            'ImFON': function (_0x4bb047, _0x17ba63) {
                return _0x4bb047(_0x17ba63);
            },
            'QNfzO': function (_0x2ad65d, _0xbd12d0) {
                return _0x2ad65d(_0xbd12d0);
            },
            'tPMrB': function (_0x529525, _0x24d196) {
                return _0x529525 - _0x24d196;
            },
            'pFygZ': function (_0x217494, _0x5c97f0) {
                return _0x217494 !== _0x5c97f0;
            },
            'BUiXs': function (_0x3f4297, _0x332038) {
                return _0x3f4297(_0x332038);
            },
            'LDIbd': function (_0x41e563, _0x458abd) {
                return _0x41e563(_0x458abd);
            },
            'HaQAB': function (_0x26d631, _0x4cd3cb) {
                return _0x26d631 - _0x4cd3cb;
            },
            'KMUdp': function (_0x19b338, _0x295ba8) {
                return _0x19b338(_0x295ba8);
            },
            'dfaSy': _0x117aed(0xe9),
            'gNvQz': function (_0x2b76f3) {
                return _0x2b76f3();
            },
            'TWkna': function (_0x150943, _0xebd682, _0x509f1a) {
                return _0x150943(_0xebd682, _0x509f1a);
            },
            'zzCDj': _0x117aed(0x16d) + _0x117aed(0xdf),
            'IgvoA': function (_0x1fb28b, _0x1da03d) {
                return _0x1fb28b - _0x1da03d;
            },
            'YFzYm': _0x117aed(0x1e6),
            'aOYaa': function (_0x4af5c8) {
                return _0x4af5c8();
            },
            'eodTN': function (_0x3dc87d) {
                return _0x3dc87d();
            },
            'cBjBS': function (_0x11caa7, _0x488466) {
                return _0x11caa7 || _0x488466;
            },
            'sLGwQ': function (_0xfde95f, _0x9282a, _0x3cbbeb) {
                return _0xfde95f(_0x9282a, _0x3cbbeb);
            },
            'CFRYA': _0x117aed(0x17d),
            'CbtjQ': _0x117aed(0x237) + _0x117aed(0x26a) + 'e\x20',
            'GKyxj': function (_0x33bcbb, _0x11baa1) {
                return _0x33bcbb - _0x11baa1;
            },
            'mCRQv': function (_0x1286bc, _0x133432) {
                return _0x1286bc(_0x133432);
            },
            'fmbBZ': function (_0x382019, _0x1df928) {
                return _0x382019 - _0x1df928;
            },
            'pzdIE': function (_0x17f732, _0x5e9eb9) {
                return _0x17f732(_0x5e9eb9);
            },
            'AfJxB': _0x117aed(0x12f),
            'LiGIS': function (_0x90e4c0) {
                return _0x90e4c0();
            },
            'HudXD': function (_0x44a361) {
                return _0x44a361();
            },
            'YpRTN': _0x117aed(0xf0),
            'NeoUN': _0x117aed(0x163) + _0x117aed(0x1db) + _0x117aed(0xed),
            'mhcXj': _0x117aed(0x13b),
            'eJgRp': function (_0x23c977, _0x22213d) {
                return _0x23c977(_0x22213d);
            },
            'MaNKL': _0x117aed(0x1e5) + 'f',
            'piDil': _0x117aed(0x277) + _0x117aed(0x10a) + _0x117aed(0x24f) + _0x117aed(0x1fd) + _0x117aed(0x17e) + _0x117aed(0x235) + _0x117aed(0x23f),
            'gZmXf': _0x117aed(0x1ff),
            'MPWNP': _0x117aed(0x199),
            'lYlsm': function (_0x314181) {
                return _0x314181();
            },
            'NrNZX': function (_0x51000f, _0x2708ee, _0x4f5c59) {
                return _0x51000f(_0x2708ee, _0x4f5c59);
            },
            'QEIBS': _0x117aed(0x12b),
            'tiwvW': _0x117aed(0x22c),
            'FEjnX': function (_0x2ccffa) {
                return _0x2ccffa();
            },
            'DDyxC': function (_0x2076a9, _0x25b21f, _0x4e936d) {
                return _0x2076a9(_0x25b21f, _0x4e936d);
            },
            'LMYVw': _0x117aed(0x19f),
            'CZnjk': _0x117aed(0x1a8),
            'NEVWZ': function (_0x2da3f1, _0x1bfbcc) {
                return _0x2da3f1(_0x1bfbcc);
            },
            'QYSnJ': _0x117aed(0x14b) + _0x117aed(0x114) + '!',
            'NrinR': function (_0xdcd449, _0x360ac6) {
                return _0xdcd449(_0x360ac6);
            },
            'EObRC': function (_0x2fefd5, _0x33419f) {
                return _0x2fefd5(_0x33419f);
            },
            'HefrU': _0x117aed(0xf1),
            'iQwwS': function (_0x4404b4) {
                return _0x4404b4();
            },
            'sZbCg': _0x117aed(0xcc),
            'PhnAL': _0x117aed(0x1e8) + _0x117aed(0x1f1),
            'fIMBd': function (_0x121c50, _0xaa5846, _0x3c335a) {
                return _0x121c50(_0xaa5846, _0x3c335a);
            },
            'HFDBT': _0x117aed(0x1b5) + _0x117aed(0x108),
            'HWxub': function (_0x215bfc, _0x1bb1b5) {
                return _0x215bfc(_0x1bb1b5);
            },
            'QhwhJ': function (_0xd6a3d8, _0x1bbf74) {
                return _0xd6a3d8(_0x1bbf74);
            },
            'jltHL': function (_0x2c29bb, _0x178c18) {
                return _0x2c29bb !== _0x178c18;
            },
            'IDfkW': function (_0x3b2487, _0x1b519b) {
                return _0x3b2487(_0x1b519b);
            }
        };
    try {
        m = _0x210cb4[_0x117aed(0x105)][0x25e + -0x411 * 0x3 + 0x9d5];
        if (!m)
            return;
        const _0x19d48a = JSON[_0x117aed(0x216)](fs[_0x117aed(0x131) + 'nc'](_0x2c7117[_0x117aed(0x234)]));
        if (m[_0x117aed(0x210)][_0x117aed(0x19c)][_0x117aed(0x242)](_0x2c7117[_0x117aed(0x1d8)]))
            return;
        const {
                mpegToOpus: _0x556afc,
                formatRupiah: _0x3f4a81,
                msToTime: _0x13cf93,
                toVoice: _0x502292,
                style: _0x41e22e,
                imageToWebp: _0x50b884,
                pinterest: _0x42c990,
                mediafireDl: _0xf2a4dc,
                ytMp4: _0x59f0e6,
                toAudio: _0x3c541d,
                UploadFileUgu: _0x178009,
                exif: _0x1da34c,
                videoToWebp: _0x340af1,
                pickRandom: _0x2c928e,
                formatDate: _0x444222,
                getTimeOn: _0x5d78ea,
                formatDateTime: _0xa335d2,
                tiktokDl: _0x401cd3,
                fetchJson: _0x13e0ec,
                sleep: _0x3440d1,
                ytMp3: _0x415122,
                randomName: _0x1447a5,
                downloadToBuffer: _0x131a6b,
                getBuffer: _0x1ff874,
                TelegraPh: _0x36d726,
                decode: _0x9ea04b
            } = _0x2c7117[_0x117aed(0x1a5)](require, _0x2c7117[_0x117aed(0x10c)]), _0x10f892 = _0x2c7117[_0x117aed(0x1a5)](getContentType, m[_0x117aed(0x1b7)]), _0x7daa42 = ((() => {
                const _0x3d2bad = _0x117aed;
                if (_0x2c7117[_0x3d2bad(0x12c)](_0x10f892, _0x2c7117[_0x3d2bad(0x24b)]))
                    return m[_0x3d2bad(0x1b7)][_0x3d2bad(0x247) + 'on'];
                else {
                    if (_0x2c7117[_0x3d2bad(0x1c6)](_0x10f892, _0x2c7117[_0x3d2bad(0x109)]))
                        return m[_0x3d2bad(0x1b7)][_0x10f892][_0x3d2bad(0x142)];
                    else {
                        if (_0x2c7117[_0x3d2bad(0x128)](_0x10f892, _0x2c7117[_0x3d2bad(0x18a)]))
                            return m[_0x3d2bad(0x1b7)][_0x10f892][_0x3d2bad(0x142)];
                        else
                            return _0x2c7117[_0x3d2bad(0x1b2)](_0x10f892, _0x2c7117[_0x3d2bad(0x150)]) ? m[_0x3d2bad(0x1b7)][_0x10f892]?.[_0x3d2bad(0x1da)] : '';
                    }
                }
            })());
        if (!_0x10f892)
            return;
        const _0x5f0b15 = _0x7daa42?.[_0x117aed(0x264)]()[_0x117aed(0x170)](/ +/)[_0x117aed(0x1f5)](-0x7af + 0x2257 + 0x1aa7 * -0x1), _0x2f3f9d = _0x7daa42?.[_0x117aed(0x264)]()[_0x117aed(0x170)](/\s+/), _0x4c41e8 = _0x2c7117[_0x117aed(0x138)](_0x2f3f9d?.[_0x117aed(0x202)], -0x2a * -0x6b + 0x121d * -0x1 + -0x4 * -0x24) ? _0x7daa42?.[_0x117aed(0x1f5)](_0x2f3f9d[-0x1e16 + -0x11e5 + -0xad * -0x47][_0x117aed(0x202)])[_0x117aed(0x264)]() : '', _0x519047 = [
                '#',
                '/',
                '.'
            ][_0x117aed(0x268)](_0x4a88af => _0x7daa42[_0x117aed(0x1c2)](_0x4a88af)) || '.', _0x21e2e9 = m?.[_0x117aed(0x1b7)][_0x10f892]?.[_0x117aed(0x121) + 'o']?.[_0x117aed(0xde) + _0x117aed(0x245)] ? m?.[_0x117aed(0x1b7)][_0x10f892]?.[_0x117aed(0x121) + 'o']?.[_0x117aed(0xde) + _0x117aed(0x245)] : null, _0x446e84 = _0x2c7117[_0x117aed(0x118)](getContentType, _0x21e2e9), _0x299667 = ((() => {
                const _0x2bed99 = _0x117aed;
                if (_0x2c7117[_0x2bed99(0x1c6)](_0x446e84, _0x2c7117[_0x2bed99(0x24b)]))
                    return _0x21e2e9[_0x446e84];
                else {
                    if (_0x2c7117[_0x2bed99(0x128)](_0x446e84, _0x2c7117[_0x2bed99(0x109)]))
                        return _0x21e2e9[_0x446e84][_0x2bed99(0x142)];
                    else {
                        if (_0x2c7117[_0x2bed99(0x1c6)](_0x446e84, _0x2c7117[_0x2bed99(0x18a)]))
                            return _0x21e2e9[_0x446e84][_0x2bed99(0x142)];
                        else
                            return _0x2c7117[_0x2bed99(0x128)](_0x446e84, _0x2c7117[_0x2bed99(0x150)]) ? _0x21e2e9[_0x446e84]?.[_0x2bed99(0x1da)] : '';
                    }
                }
            })()), _0xbb5536 = m[_0x117aed(0x1b7)][_0x10f892]?.[_0x117aed(0x121) + 'o']?.[_0x117aed(0x248) + 't'] ? m[_0x117aed(0x1b7)]?.[_0x117aed(0xf4) + _0x117aed(0x166)]?.[_0x117aed(0x121) + 'o']?.[_0x117aed(0x248) + 't'] : null, _0x16e0a3 = m[_0x117aed(0x1b7)][_0x10f892]?.[_0x117aed(0x121) + 'o']?.[_0x117aed(0x12e)] ? m[_0x117aed(0x1b7)]?.[_0x117aed(0xf4) + _0x117aed(0x166)]?.[_0x117aed(0x121) + 'o']?.[_0x117aed(0x12e)] : null, _0xa5f261 = ((() => {
                const _0x298309 = _0x117aed;
                if (m?.[_0x298309(0x1b7)]?.[_0x298309(0x21c) + 'ge'])
                    return m[_0x298309(0x1b7)][_0x298309(0x21c) + 'ge'];
                else {
                    if (m?.[_0x298309(0x1b7)]?.[_0x298309(0x233) + 'ge'])
                        return m[_0x298309(0x1b7)][_0x298309(0x233) + 'ge'];
                    else {
                        if (m?.[_0x298309(0x1b7)]?.[_0x298309(0x275) + 'ge'])
                            return m[_0x298309(0x1b7)][_0x298309(0x275) + 'ge'];
                        else {
                            if (_0x21e2e9?.[_0x298309(0x21c) + 'ge'])
                                return _0x21e2e9[_0x298309(0x21c) + 'ge'];
                            else {
                                if (_0x21e2e9?.[_0x298309(0x233) + 'ge'])
                                    return _0x21e2e9[_0x298309(0x233) + 'ge'];
                                else {
                                    if (_0x21e2e9?.[_0x298309(0x275) + 'ge'])
                                        return _0x21e2e9[_0x298309(0x275) + 'ge'];
                                    else
                                        return _0x21e2e9?.[_0x298309(0xee) + _0x298309(0x1e0)] ? _0x21e2e9[_0x298309(0xee) + _0x298309(0x1e0)] : null;
                                }
                            }
                        }
                    }
                }
            })()), _0x5dd4b1 = m[_0x117aed(0x210)][_0x117aed(0x19c)] || '', _0x1ba87d = _0x5dd4b1[_0x117aed(0x1a3)](_0x2c7117[_0x117aed(0x22d)]) ? m[_0x117aed(0x210)][_0x117aed(0x1ae)] ? _0x1d6150[_0x117aed(0x11f)][_0x117aed(0xe4)] : _0x5dd4b1 : m[_0x117aed(0x210)][_0x117aed(0x248) + 't'], _0x4e8a5b = _0x2c7117[_0x117aed(0x1c6)](_0x2c7117[_0x117aed(0x274)](contact, _0x2c7117[_0x117aed(0x22d)]), _0x1ba87d) ? !![] : ![], _0xfd9afe = _0xa5f261?.[_0x117aed(0x222)] || null, _0x598f62 = _0x1d6150?.[_0x117aed(0x11f)]?.[_0x117aed(0xe4)] || '', _0x3f8328 = _0x2c7117[_0x117aed(0x12c)](_0x1ba87d, _0x598f62) ? !![] : ![], _0x5a290a = _0x7daa42?.[_0x117aed(0x1f5)](0x1375 + -0xd * 0x1bd + -0x325 * -0x1)[_0x117aed(0x170)]('\x20')[-0x1 * 0x22d7 + 0x96c + 0x196b][_0x117aed(0xeb) + 'e']() || '', _0x167a71 = _0x5dd4b1[_0x117aed(0x1a3)](_0x2c7117[_0x117aed(0x1ef)]) ? !![] : ![];
        async function _0x491ca4() {
            const _0x28f144 = _0x117aed;
            let _0x58df46 = _0x28f144(0x16f) + _0x1ba87d[_0x28f144(0x170)]('@')[-0xf22 + -0xe2a + -0x1e * -0xfa] + _0x28f144(0x16e) + _0x519047 + _0x5a290a + (_0x28f144(0x223) + _0x28f144(0xff) + _0x28f144(0x1bb) + _0x28f144(0x1a4));
            await _0x2c7117[_0x28f144(0x1bf)](_0x274000, _0x58df46);
        }
        async function _0x4fa348() {
            const _0x4cda22 = _0x117aed;
            let _0x2d70a5 = _0x4cda22(0x16f) + _0x1ba87d[_0x4cda22(0x170)]('@')[0x7db * -0x3 + 0x1 * -0x62b + 0x1dbc] + _0x4cda22(0x16e) + _0x519047 + _0x5a290a + (_0x4cda22(0x223) + _0x4cda22(0xff) + _0x4cda22(0x211) + _0x4cda22(0x15d));
            await _0x2c7117[_0x4cda22(0x1bf)](_0x274000, _0x2d70a5);
        }
        async function _0x137fe9() {
            const _0x381638 = _0x117aed;
            let _0x4b0e49 = _0x381638(0x16f) + _0x1ba87d[_0x381638(0x170)]('@')[-0xc0f * 0x2 + -0x19b0 + -0x4b * -0xaa] + _0x381638(0x16e) + _0x519047 + _0x5a290a + (_0x381638(0x223) + _0x381638(0xff) + _0x381638(0xd3) + _0x381638(0x126) + '!');
            await _0x2c7117[_0x381638(0x1bf)](_0x274000, _0x4b0e49);
        }
        const _0x531526 = {
            'key': {
                'remoteJid': _0x2c7117[_0x117aed(0x1cb)],
                'fromMe': ![],
                'participant': _0x2c7117[_0x117aed(0x144)]
            },
            'message': {
                'documentMessage': {
                    'mimetype': _0x2c7117[_0x117aed(0x169)],
                    'fileName': _0x2c7117[_0x117aed(0xf7)](_0x41e22e, _0x117aed(0x269) + _0x117aed(0x1f7) + (_0x7daa42[_0x117aed(0x1c2)](_0x519047) ? _0x5a290a : _0x10f892))
                }
            }
        };
        async function _0x5591fc(_0x430051, _0x19d4c0) {
            const _0x2ac01c = _0x117aed;
            let _0x49a54e = b + (_0x2ac01c(0x13e) + '\x20]') + b + '\x0a' + _0x519047 + _0x5a290a + '\x20' + _0x430051 + '\x0a\x0a' + b + (_0x2ac01c(0xd0) + ']') + b + '\x0a' + _0x519047 + _0x5a290a + '\x20' + _0x19d4c0;
            _0x2c7117[_0x2ac01c(0x24e)](_0x274000, _0x49a54e);
        }
        async function _0x274000(_0x1e62ca, _0x284b77 = _0x5dd4b1, _0x49bb6b = !![]) {
            const _0x499e44 = _0x117aed;
            let _0x6b5b11 = _0x2c7117[_0x499e44(0x178)](_0x1e62ca, '');
            const _0x15f985 = await _0x2c7117[_0x499e44(0x1bf)](_0x131a6b, JSON[_0x499e44(0x216)](fs[_0x499e44(0x131) + 'nc'](_0x499e44(0x149) + _0x499e44(0x205) + _0x499e44(0x226) + Math[_0x499e44(0x18b)](_0x2c7117[_0x499e44(0x1d6)](Math[_0x499e44(0x23b)](), -0xdb0 + -0xa3 * -0x8 + 0x2 * 0x44f)) + _0x499e44(0xca))));
            await _0x1d6150[_0x499e44(0x253) + 'e'](_0x284b77, {
                'image': _0x15f985,
                'caption': _0x2c7117[_0x499e44(0x1a5)](_0x41e22e, header + '\x0a\x0a' + _0x6b5b11 + _0x499e44(0x246) + footer + '_'),
                'mentions': [_0x1ba87d],
                'contextInfo': {
                    'mentionedJid': (_0x6b5b11[_0x499e44(0xd2)](/@(\d+)/g) || [])[_0x499e44(0x24a)](_0x52cfce => _0x52cfce[_0x499e44(0x1f5)](-0x3 * 0x7aa + -0x148a + 0x2b89 * 0x1) + (_0x499e44(0x137) + _0x499e44(0x140))),
                    'forwardingScore': 0x270f,
                    'isForwarded': !![],
                    'forwardedNewsletterMessageInfo': {
                        'newsletterJid': sletter,
                        'newsletterName': _0x2c7117[_0x499e44(0x1bf)](_0x41e22e, name)
                    }
                }
            }, { 'quoted': _0x531526 });
        }
        if (_0x7daa42[_0x117aed(0x1c2)](_0x519047)) {
            if (_0x2c7117[_0x117aed(0x104)](JSON[_0x117aed(0x216)](fs[_0x117aed(0x131) + 'nc'](_0x2c7117[_0x117aed(0x180)]))[_0x117aed(0x1ce)], _0x2c7117[_0x117aed(0x26e)])) {
                if (!_0x3f8328)
                    return;
            }
            console[_0x117aed(0x14a)](chalk[_0x117aed(0x1c4)](_0x2c7117[_0x117aed(0x1dc)])(_0x2c7117[_0x117aed(0x24e)](_0x41e22e, _0x117aed(0x262) + _0x117aed(0x1c8) + _0x117aed(0x1ab) + _0x117aed(0xdc) + _0x117aed(0x127) + _0x117aed(0x1c8) + _0x117aed(0x238) + _0x117aed(0x1a6) + _0x598f62 + (_0x117aed(0x221) + _0x117aed(0x15c) + _0x117aed(0x1eb) + _0x117aed(0x107) + _0x117aed(0x183)) + _0x1ba87d + (_0x117aed(0x13a) + _0x117aed(0x159)) + _0x7daa42 + (_0x117aed(0x14e) + _0x117aed(0x1c8) + _0x117aed(0x1f0) + _0x117aed(0x1c0) + _0x117aed(0x20d) + _0x117aed(0x1c8) + _0x117aed(0x20b)))));
            switch (_0x5a290a) {
            case _0x2c7117[_0x117aed(0x18f)]: {
                    let _0x435081 = b + (_0x117aed(0xe6) + '\x20]') + b + '\x0a' + b3 + (_0x117aed(0x185) + _0x117aed(0x1fa) + _0x117aed(0x1a9) + _0x117aed(0x1cf) + _0x117aed(0x1b8) + ':\x20') + author + (_0x117aed(0x227) + _0x117aed(0x17a)) + _0x519047 + _0x117aed(0x117) + b3 + '\x0a' + read + '\x0a' + b + (_0x117aed(0x1d5) + _0x117aed(0x167)) + b + '\x0a\x0a' + _0x519047 + _0x117aed(0x23a) + _0x519047 + (_0x117aed(0x22e) + '\x0a') + b + (_0x117aed(0x1f9) + _0x117aed(0x167)) + b + '\x0a\x0a' + _0x519047 + _0x117aed(0xfe) + _0x519047 + _0x117aed(0x158) + _0x519047 + _0x117aed(0x1f2) + _0x519047 + _0x117aed(0x11a) + _0x519047 + _0x117aed(0x1d2) + _0x519047 + _0x117aed(0x179) + _0x519047 + (_0x117aed(0x113) + '-\x0a') + _0x519047 + _0x117aed(0x1f6) + _0x519047 + _0x117aed(0x229) + _0x519047 + _0x117aed(0x197) + _0x519047 + (_0x117aed(0x231) + '-\x0a');
                    _0x2c7117[_0x117aed(0x217)](_0x274000, _0x435081);
                }
                break;
            case _0x2c7117[_0x117aed(0x26e)]: {
                    if (!_0x3f8328)
                        return _0x2c7117[_0x117aed(0x15b)](_0x137fe9);
                    fs[_0x117aed(0xcf) + _0x117aed(0x122)](_0x2c7117[_0x117aed(0x180)], JSON[_0x117aed(0xd7)]({ 'mode': _0x2c7117[_0x117aed(0x26e)] }, null, -0x4 * 0x2db + -0x24a6 + -0x1 * -0x3014)), _0x2c7117[_0x117aed(0x1bf)](_0x274000, _0x2c7117[_0x117aed(0x157)]);
                }
                break;
            case _0x2c7117[_0x117aed(0x209)]: {
                    if (!_0x3f8328)
                        return _0x2c7117[_0x117aed(0x244)](_0x137fe9);
                    fs[_0x117aed(0xcf) + _0x117aed(0x122)](_0x2c7117[_0x117aed(0x180)], JSON[_0x117aed(0xd7)]({ 'mode': _0x2c7117[_0x117aed(0x209)] }, null, -0xd17 + 0x2565 * 0x1 + -0xa * 0x26e)), _0x2c7117[_0x117aed(0x215)](_0x274000, _0x2c7117[_0x117aed(0x155)]);
                }
                break;
            case _0x2c7117[_0x117aed(0x1ec)]: {
                    if (!_0x3f8328)
                        return _0x2c7117[_0x117aed(0x244)](_0x137fe9);
                    if (_0x2c7117[_0x117aed(0x11e)](!_0x4c41e8, !_0x299667))
                        return _0x2c7117[_0x117aed(0x10d)](_0x5591fc, _0x2c7117[_0x117aed(0x146)], _0x2c7117[_0x117aed(0x26d)]);
                    const _0x341182 = _0x2c7117[_0x117aed(0x178)](_0x4c41e8, _0x299667) || '', _0xee4210 = _0xa5f261 ? await _0x2c7117[_0x117aed(0x191)](_0x131a6b, _0xa5f261) : null;
                    let _0x238936 = -0x214f + -0x224f + 0x439e, _0x3b9a3e = await _0x1d6150[_0x117aed(0xfa) + _0x117aed(0x1b0) + _0x117aed(0x214)](), _0x21fb36 = Object[_0x117aed(0x1df)](_0x3b9a3e)[_0x117aed(0x1f5)](-0x4ae * -0x4 + -0x1326 + -0xa * -0xb)[_0x117aed(0x24a)](_0x5b5f46 => _0x5b5f46[-0x2 * -0x8f5 + -0x26ef + -0x381 * -0x6]), _0x1a6304 = _0x21fb36[_0x117aed(0x120)](_0x96972c => {
                            const _0x54e2c6 = _0x117aed;
                            let _0x316943 = _0x96972c[_0x54e2c6(0x248) + 'ts'][_0x54e2c6(0x136)](_0x1ae5e2 => _0x1ae5e2[_0x54e2c6(0x1be)] !== null && _0x1ae5e2['id'] === _0x598f62);
                            return _0x2c7117[_0x54e2c6(0x272)](_0x96972c[_0x54e2c6(0x261)], ![]) || _0x316943;
                        }), _0x78580b = _0x1a6304?.[_0x117aed(0x24a)](_0x21f3f1 => _0x21f3f1['id']);
                    await _0x2c7117[_0x117aed(0x24e)](_0x274000, _0x117aed(0x190) + _0x117aed(0x10b) + _0x117aed(0x255) + _0x78580b[_0x117aed(0x202)]);
                    for (let _0x41807e of _0x78580b) {
                        _0xee4210 ? await _0x1d6150[_0x117aed(0x253) + 'e'](_0x41807e, {
                            'image': _0xee4210,
                            'caption': _0x341182
                        }, { 'quoted': _0x531526 }) : await _0x1d6150[_0x117aed(0x253) + 'e'](_0x41807e, { 'text': _0x341182 }, { 'quoted': _0x531526 }), _0x238936 += 0x1f1b + 0xb * 0x33f + -0x3 * 0x1645, await _0x2c7117[_0x117aed(0x196)](_0x3440d1, -0x4d46 + -0x254d + 0x99a3);
                    }
                    let _0x41725b = _0x117aed(0x1fb) + _0x117aed(0x165) + _0x117aed(0x276) + _0x238936 + _0x117aed(0xd8);
                    await _0x2c7117[_0x117aed(0x13f)](_0x274000, _0x41725b);
                }
                break;
            case _0x2c7117[_0x117aed(0x1ee)]: {
                    if (!_0x3f8328)
                        return _0x2c7117[_0x117aed(0x1f3)](_0x137fe9);
                    if (_0x2c7117[_0x117aed(0x11e)](!_0x4c41e8, !_0x299667))
                        return _0x2c7117[_0x117aed(0xfb)](_0x5591fc, _0x2c7117[_0x117aed(0x146)], _0x2c7117[_0x117aed(0x26d)]);
                    const _0xcc04e6 = _0x2c7117[_0x117aed(0x184)](_0x4c41e8, _0x299667) || '', _0x485b3b = _0xa5f261 ? await _0x2c7117[_0x117aed(0x204)](_0x131a6b, _0xa5f261) : null;
                    let _0x257072 = 0x1682 * -0x1 + 0x11 * 0x233 + -0xd * 0x125, _0x404a0b = await _0x1d6150[_0x117aed(0xfa) + _0x117aed(0x1b0) + _0x117aed(0x214)](), _0x5b1d20 = Object[_0x117aed(0x1df)](_0x404a0b)[_0x117aed(0x1f5)](0x22b2 + -0x2094 + 0x2 * -0x10f)[_0x117aed(0x24a)](_0xd0a39 => _0xd0a39[-0x670 + 0x107 * 0x25 + -0x3 * 0xa86]), _0xc63ccc = _0x5b1d20[_0x117aed(0x120)](_0x3e97fe => _0x3e97fe[_0x117aed(0x261)] == ![]), _0x5761b5 = _0xc63ccc?.[_0x117aed(0x24a)](_0x4b0495 => _0x4b0495['id']);
                    await _0x2c7117[_0x117aed(0x14c)](_0x274000, _0x117aed(0x190) + _0x117aed(0x10b) + _0x117aed(0x255) + _0x5761b5[_0x117aed(0x202)]);
                    for (let _0x34c52e of _0x5761b5) {
                        _0x485b3b ? await _0x1d6150[_0x117aed(0x253) + 'e'](_0x34c52e, {
                            'image': _0x485b3b,
                            'caption': _0xcc04e6,
                            'mentions': _0xc63ccc?.[_0x117aed(0x248) + 'ts']
                        }, { 'quoted': _0x531526 }) : await _0x1d6150[_0x117aed(0x253) + 'e'](_0x34c52e, { 'text': _0xcc04e6 }, { 'quoted': _0x531526 }), _0x257072 += -0x40e + -0x227d + 0x268c, await _0x2c7117[_0x117aed(0x204)](_0x3440d1, -0x2ad2 + 0x2a44 + 0x279e);
                    }
                    let _0x2a7bdb = _0x117aed(0x1fb) + _0x117aed(0x165) + _0x117aed(0x276) + _0x257072 + _0x117aed(0xd8);
                    await _0x2c7117[_0x117aed(0x25b)](_0x274000, _0x2a7bdb);
                }
                break;
            case _0x2c7117[_0x117aed(0x17b)]: {
                    if (!_0x3f8328)
                        return _0x2c7117[_0x117aed(0x244)](_0x137fe9);
                    const [_0x3c4f71, _0x3fe758] = _0x4c41e8[_0x117aed(0x170)](',');
                    if (_0x2c7117[_0x117aed(0x184)](!_0x3c4f71, !_0x3fe758))
                        return _0x2c7117[_0x117aed(0xfb)](_0x5591fc, _0x2c7117[_0x117aed(0x1fc)], _0x2c7117[_0x117aed(0x1cd)]);
                    let _0x40e2e7;
                    try {
                        _0x40e2e7 = await _0x1d6150[_0x117aed(0x101) + _0x117aed(0x25d)](_0x3c4f71[_0x117aed(0x264)]());
                    } catch (_0x32d24c) {
                        return _0x2c7117[_0x117aed(0x200)](_0x274000, _0x2c7117[_0x117aed(0x154)]);
                    }
                    const _0x22e4a3 = await _0x40e2e7[_0x117aed(0x248) + 'ts'], _0x4a6eef = await _0x22e4a3[_0x117aed(0x120)](_0x572eed => _0x572eed['id'][_0x117aed(0x1a3)](_0x117aed(0x11d)))[_0x117aed(0x24a)](_0x43ba78 => _0x43ba78['id']);
                    await _0x2c7117[_0x117aed(0x186)](_0x274000, _0x117aed(0x190) + _0x117aed(0xf3) + _0x117aed(0x148) + _0x2c7117[_0x117aed(0x193)](_0x4a6eef[_0x117aed(0x202)], 0x9a4 * -0x2 + -0xed * -0x3 + 0x1082) + (_0x117aed(0x106) + _0x117aed(0xcd)));
                    for (let _0x3b44d7 of _0x4a6eef) {
                        _0x2c7117[_0x117aed(0x254)](_0x3b44d7, _0x1ba87d) && (await _0x1d6150[_0x117aed(0x253) + 'e'](_0x3b44d7, {
                            'text': _0x3fe758,
                            'ai': !![]
                        }, { 'quoted': _0x531526 }), await _0x2c7117[_0x117aed(0xe1)](_0x3440d1, 0x771 + -0x4b3f + -0x2 * -0x356f));
                    }
                    let _0x2238f7 = _0x117aed(0x1fb) + _0x117aed(0x165) + _0x117aed(0x276) + _0x2c7117[_0x117aed(0x12d)](_0x4a6eef[_0x117aed(0x202)], 0x9d * -0x3a + -0xcfa + -0x3 * -0x102f) + _0x117aed(0x26f);
                    await _0x2c7117[_0x117aed(0x23c)](_0x274000, _0x2238f7);
                }
                break;
            case _0x2c7117[_0x117aed(0xf5)]: {
                    if (!_0x3f8328)
                        return _0x2c7117[_0x117aed(0x244)](_0x137fe9);
                    const [_0x290a99, _0x491f8a, _0x3b1e91] = _0x4c41e8[_0x117aed(0x170)](',');
                    if (_0x2c7117[_0x117aed(0x10f)](!_0x290a99, !_0x491f8a) || !_0x3b1e91)
                        return _0x2c7117[_0x117aed(0x143)](_0x5591fc, _0x2c7117[_0x117aed(0x20c)], _0x2c7117[_0x117aed(0x168)]);
                    let _0x4aa718;
                    try {
                        _0x4aa718 = await _0x1d6150[_0x117aed(0x101) + _0x117aed(0x25d)](_0x290a99[_0x117aed(0x264)]());
                    } catch (_0x358b9b) {
                        return _0x2c7117[_0x117aed(0x1cc)](_0x274000, _0x2c7117[_0x117aed(0x154)]);
                    }
                    const _0x8bdc54 = await _0x4aa718[_0x117aed(0x248) + 'ts'], _0xb3bfe8 = await _0x8bdc54[_0x117aed(0x120)](_0x445552 => _0x445552['id'][_0x117aed(0x1a3)](_0x117aed(0x11d)))[_0x117aed(0x24a)](_0x35af1c => _0x35af1c['id']);
                    await _0x2c7117[_0x117aed(0xf8)](_0x274000, _0x117aed(0x190) + _0x117aed(0xf3) + _0x117aed(0x148) + _0x2c7117[_0x117aed(0x124)](_0xb3bfe8[_0x117aed(0x202)], -0x1 * -0x116d + -0x1fa2 + 0xe36) + (_0x117aed(0x106) + _0x117aed(0xcd)));
                    for (let _0x314fdf of _0xb3bfe8) {
                        _0x2c7117[_0x117aed(0x1f8)](_0x314fdf, _0x1ba87d) && (await _0x1d6150[_0x117aed(0x253) + 'e'](_0x314fdf, {
                            'text': _0x3b1e91,
                            'ai': !![]
                        }, { 'quoted': _0x531526 }), await _0x2c7117[_0x117aed(0xec)](_0x3440d1, _0x2c7117[_0x117aed(0x145)](Number, _0x491f8a)));
                    }
                    let _0x3f5cdb = _0x117aed(0x1fb) + _0x117aed(0x165) + _0x117aed(0x276) + _0x2c7117[_0x117aed(0xdd)](_0xb3bfe8[_0x117aed(0x202)], 0x30 + -0xc8 * 0x2f + 0x2489) + _0x117aed(0x26f);
                    await _0x2c7117[_0x117aed(0x206)](_0x274000, _0x3f5cdb);
                }
                break;
            case _0x2c7117[_0x117aed(0x16a)]: {
                    if (!_0x3f8328)
                        return _0x2c7117[_0x117aed(0x15b)](_0x137fe9);
                    if (!_0x167a71)
                        return _0x2c7117[_0x117aed(0x1e9)](_0x491ca4);
                    if (!_0x4c41e8)
                        return _0x2c7117[_0x117aed(0x230)](_0x5591fc, _0x2c7117[_0x117aed(0x146)], _0x2c7117[_0x117aed(0xe2)]);
                    const _0x49c8a3 = _0x5dd4b1, _0x1eb89a = _0x4c41e8, _0x5b1789 = await _0x1d6150[_0x117aed(0x101) + _0x117aed(0x25d)](_0x49c8a3[_0x117aed(0x264)]()), _0x2c22dd = await _0x5b1789[_0x117aed(0x248) + 'ts'], _0x19b862 = await _0x2c22dd[_0x117aed(0x120)](_0x590428 => _0x590428['id'][_0x117aed(0x1a3)](_0x117aed(0x11d)))[_0x117aed(0x24a)](_0x319687 => _0x319687['id']);
                    await _0x2c7117[_0x117aed(0xf8)](_0x274000, _0x117aed(0x190) + _0x117aed(0xf3) + _0x117aed(0x148) + _0x2c7117[_0x117aed(0xdd)](_0x19b862[_0x117aed(0x202)], 0x6df * -0x1 + 0x17c4 + 0x10e4 * -0x1) + (_0x117aed(0x106) + _0x117aed(0xcd)));
                    for (let _0x30eb44 of _0x19b862) {
                        _0x2c7117[_0x117aed(0x254)](_0x30eb44, _0x1ba87d) && (await _0x1d6150[_0x117aed(0x253) + 'e'](_0x30eb44, {
                            'text': _0x1eb89a,
                            'ai': !![]
                        }, { 'quoted': _0x531526 }), await _0x2c7117[_0x117aed(0x118)](_0x3440d1, 0x1 * 0x2c57 + -0x2c5b + -0xf4 * -0x29));
                    }
                    let _0x440332 = _0x117aed(0x1fb) + _0x117aed(0x165) + _0x117aed(0x276) + _0x2c7117[_0x117aed(0x241)](_0x19b862[_0x117aed(0x202)], 0x1849 + 0x40 * -0x2 + -0x17c8) + _0x117aed(0x26f);
                    await _0x2c7117[_0x117aed(0x204)](_0x274000, _0x440332);
                }
                break;
            case _0x2c7117[_0x117aed(0x189)]: {
                    if (!_0x3f8328)
                        return _0x2c7117[_0x117aed(0x220)](_0x137fe9);
                    if (!_0x167a71)
                        return _0x2c7117[_0x117aed(0x263)](_0x491ca4);
                    const [_0x1b83c3, _0x4ce0d7] = _0x4c41e8[_0x117aed(0x170)](',');
                    if (_0x2c7117[_0x117aed(0x1dd)](!_0x1b83c3, !_0x4ce0d7))
                        return _0x2c7117[_0x117aed(0x147)](_0x5591fc, _0x2c7117[_0x117aed(0x257)], _0x2c7117[_0x117aed(0x1c5)]);
                    const _0x24ee2f = _0x5dd4b1, _0x2f1e50 = await _0x1d6150[_0x117aed(0x101) + _0x117aed(0x25d)](_0x24ee2f[_0x117aed(0x264)]()), _0x139dd9 = await _0x2f1e50[_0x117aed(0x248) + 'ts'], _0x3b0ed1 = await _0x139dd9[_0x117aed(0x120)](_0x2798c4 => _0x2798c4['id'][_0x117aed(0x1a3)](_0x117aed(0x11d)))[_0x117aed(0x24a)](_0x5e2e56 => _0x5e2e56['id']);
                    await _0x2c7117[_0x117aed(0x186)](_0x274000, _0x117aed(0x190) + _0x117aed(0xf3) + _0x117aed(0x148) + _0x2c7117[_0x117aed(0x1ea)](_0x3b0ed1[_0x117aed(0x202)], -0x1673 * -0x1 + 0x3 + -0x1675 * 0x1) + (_0x117aed(0x106) + _0x117aed(0xcd)));
                    for (let _0x5c250a of _0x3b0ed1) {
                        _0x2c7117[_0x117aed(0x254)](_0x5c250a, _0x1ba87d) && (await _0x1d6150[_0x117aed(0x253) + 'e'](_0x5c250a, {
                            'text': _0x4ce0d7,
                            'ai': !![]
                        }, { 'quoted': _0x531526 }), await _0x2c7117[_0x117aed(0x267)](_0x3440d1, _0x2c7117[_0x117aed(0x267)](Number, _0x1b83c3)));
                    }
                    let _0x52d611 = _0x117aed(0x1fb) + _0x117aed(0x165) + _0x117aed(0x276) + _0x2c7117[_0x117aed(0x188)](_0x3b0ed1[_0x117aed(0x202)], 0x8 * -0xb7 + -0x1 * 0xb9e + 0x1157) + _0x117aed(0x26f);
                    await _0x2c7117[_0x117aed(0x175)](_0x274000, _0x52d611);
                }
                break;
            case _0x2c7117[_0x117aed(0x164)]: {
                    if (!_0x3f8328)
                        return _0x2c7117[_0x117aed(0x251)](_0x137fe9);
                    if (_0x167a71)
                        return _0x2c7117[_0x117aed(0xcb)](onlyPrivate);
                    let _0x405fb4 = Object[_0x117aed(0x153)](await _0x1d6150[_0x117aed(0xfa) + _0x117aed(0x1b0) + _0x117aed(0x214)]()[_0x117aed(0x15f)](_0x86771b => null)), _0x2d7b17 = b + (_0x117aed(0x103) + _0x117aed(0x1b1)) + b + '\x0a' + b3 + _0x117aed(0x250) + _0x405fb4[_0x117aed(0x202)] + _0x117aed(0x192) + _0x405fb4[_0x117aed(0x120)](_0x4be985 => _0x4be985[_0x117aed(0x261)] === !![])[_0x117aed(0x202)] + _0x117aed(0x252) + _0x405fb4[_0x117aed(0x120)](_0x12538a => _0x12538a[_0x117aed(0x261)] === ![])[_0x117aed(0x202)] + '\x0a' + b3;
                    await _0x405fb4[_0x117aed(0x260)]((_0x723016, _0x3f8bb8) => {
                        const _0x2c7dee = _0x117aed, _0x13d8ed = _0x723016[_0x2c7dee(0x14d)] ? _0x723016[_0x2c7dee(0x14d)][_0x2c7dee(0x170)]('@')[0xc29 + 0xa3b + -0x4 * 0x599] : _0x2c7117[_0x2c7dee(0xf6)], _0x92352d = _0x723016[_0x2c7dee(0x261)] ? _0x2c7117[_0x2c7dee(0x249)] : _0x2c7117[_0x2c7dee(0x112)];
                        _0x2d7b17 += '\x0a\x0a' + b + '[\x20' + _0x723016[_0x2c7dee(0xe7)] + '\x20]' + b + '\x0a' + b3 + _0x2c7dee(0x1e3) + _0x723016[_0x2c7dee(0x248) + 'ts'][_0x2c7dee(0x202)] + _0x2c7dee(0x18d) + _0x13d8ed + _0x2c7dee(0x239) + _0x92352d + _0x2c7dee(0xef) + _0x723016['id'] + '\x0a' + b3;
                    }), _0x2c7117[_0x117aed(0x200)](_0x274000, _0x2d7b17);
                }
                break;
            case _0x2c7117[_0x117aed(0x135)]: {
                    if (!_0x3f8328)
                        return _0x2c7117[_0x117aed(0xcb)](_0x137fe9);
                    if (!_0x167a71)
                        return _0x2c7117[_0x117aed(0x1f3)](_0x491ca4);
                    let _0x194fe1 = await _0x1d6150[_0x117aed(0x101) + _0x117aed(0x25d)](_0x5dd4b1), _0xe608f = _0x194fe1[_0x117aed(0x248) + 'ts'][_0x117aed(0x24a)](_0x131be7 => _0x131be7['id'])[_0x117aed(0x120)](_0x4ad999 => _0x4ad999 !== _0x1ba87d);
                    _0xe608f[_0x117aed(0x260)](async _0x398ce5 => {
                        const _0x1799d3 = _0x117aed;
                        _0x19d48a[_0x1799d3(0xe9)](_0x398ce5), fs[_0x1799d3(0xcf) + _0x1799d3(0x122)](_0x2c7117[_0x1799d3(0x1c3)], JSON[_0x1799d3(0xd7)](_0x19d48a));
                    });
                    try {
                        const _0x23a6a2 = [...new Set(_0x19d48a)], _0x21bd42 = _0x23a6a2[_0x117aed(0x24a)]((_0x454a3f, _0x33b57a) => {
                                const _0x3a8eaa = _0x117aed, _0x14e7c5 = [
                                        _0x2c7117[_0x3a8eaa(0xce)],
                                        _0x2c7117[_0x3a8eaa(0x15a)],
                                        _0x3a8eaa(0x243) + '[' + _0x454a3f[_0x3a8eaa(0x170)]('@')[-0x267d + -0xf53 * -0x1 + 0x172a] + ']',
                                        _0x3a8eaa(0x21f) + _0x3a8eaa(0x22a) + _0x3a8eaa(0x12a) + _0x454a3f[_0x3a8eaa(0x170)]('@')[-0x3 * -0x8d7 + -0x1d04 + 0x27f] + ':+' + _0x454a3f[_0x3a8eaa(0x170)]('@')[-0x1a * 0x64 + -0x24c6 * -0x1 + -0x1a9e],
                                        _0x2c7117[_0x3a8eaa(0x1a1)],
                                        ''
                                    ][_0x3a8eaa(0x21d)]('\x0a');
                                return _0x14e7c5;
                            })[_0x117aed(0x21d)]('');
                        fs[_0x117aed(0xcf) + _0x117aed(0x122)](_0x2c7117[_0x117aed(0x26c)], _0x21bd42, _0x2c7117[_0x117aed(0x1af)]);
                    } catch (_0x3ee2dc) {
                        await _0x2c7117[_0x117aed(0xd9)](_0x274000, _0x3ee2dc[_0x117aed(0xd6)]());
                    } finally {
                        if (_0x2c7117[_0x117aed(0x254)](_0x5dd4b1, _0x1ba87d))
                            await _0x2c7117[_0x117aed(0x1bf)](_0x274000, _0x117aed(0x15e) + _0x117aed(0x1e4) + _0x117aed(0x19a) + _0x117aed(0x273) + _0x117aed(0xf2));
                        await _0x1d6150[_0x117aed(0x253) + 'e'](_0x1ba87d, {
                            'document': fs[_0x117aed(0x131) + 'nc'](_0x2c7117[_0x117aed(0x26c)]),
                            'fileName': _0x2c7117[_0x117aed(0x16c)],
                            'caption': _0x2c7117[_0x117aed(0x265)],
                            'mimetype': _0x2c7117[_0x117aed(0xe8)],
                            'contextInfo': {
                                'mentionedJid': [_0x1ba87d],
                                'forwardingScore': 0x270f,
                                'isForwarded': !![]
                            }
                        }, { 'quoted': _0x531526 }), _0x19d48a[_0x117aed(0x151)](-0x201a + -0x1e2d + 0x6b * 0x95, _0x19d48a[_0x117aed(0x202)]);
                    }
                }
                break;
            case _0x2c7117[_0x117aed(0x13d)]: {
                    if (!_0x3f8328)
                        return _0x2c7117[_0x117aed(0x251)](_0x137fe9);
                    if (!_0x167a71)
                        return _0x2c7117[_0x117aed(0x1ba)](_0x491ca4);
                    if (!_0x4c41e8)
                        return _0x2c7117[_0x117aed(0x162)](_0x5591fc, _0x2c7117[_0x117aed(0x161)], author);
                    let _0x7270bf = await _0x1d6150[_0x117aed(0x101) + _0x117aed(0x25d)](_0x5dd4b1), _0x6e740 = _0x7270bf[_0x117aed(0x248) + 'ts'][_0x117aed(0x24a)](_0x835a56 => _0x835a56['id'])[_0x117aed(0x120)](_0x442580 => _0x442580 !== _0x1ba87d);
                    _0x6e740[_0x117aed(0x260)](async _0x731690 => {
                        const _0x13e71d = _0x117aed;
                        _0x19d48a[_0x13e71d(0xe9)](_0x731690), fs[_0x13e71d(0xcf) + _0x13e71d(0x122)](_0x2c7117[_0x13e71d(0x1c3)], JSON[_0x13e71d(0xd7)](_0x19d48a));
                    });
                    try {
                        const _0x4b6df6 = [...new Set(_0x19d48a)], _0x3b7aba = _0x4b6df6[_0x117aed(0x24a)]((_0x2d8477, _0x591ef0) => {
                                const _0x27f182 = _0x117aed, _0xec2075 = [
                                        _0x2c7117[_0x27f182(0xce)],
                                        _0x2c7117[_0x27f182(0x15a)],
                                        _0x27f182(0x1f4) + _0x4c41e8 + '\x20[' + _0x2d8477[_0x27f182(0x170)]('@')[0x16af * 0x1 + -0x1c0c + 0x55d] + ']',
                                        _0x27f182(0x21f) + _0x27f182(0x22a) + _0x27f182(0x12a) + _0x2d8477[_0x27f182(0x170)]('@')[0x79a + -0x2 * 0xfd + 0x1e * -0x30] + ':+' + _0x2d8477[_0x27f182(0x170)]('@')[-0x1 * 0xaa7 + 0x228f + -0x33 * 0x78],
                                        _0x2c7117[_0x27f182(0x1a1)],
                                        ''
                                    ][_0x27f182(0x21d)]('\x0a');
                                return _0xec2075;
                            })[_0x117aed(0x21d)]('');
                        fs[_0x117aed(0xcf) + _0x117aed(0x122)](_0x2c7117[_0x117aed(0x26c)], _0x3b7aba, _0x2c7117[_0x117aed(0x1af)]);
                    } catch (_0x3e0336) {
                        await _0x2c7117[_0x117aed(0x196)](_0x274000, _0x3e0336[_0x117aed(0xd6)]());
                    } finally {
                        if (_0x2c7117[_0x117aed(0x1f8)](_0x5dd4b1, _0x1ba87d))
                            await _0x2c7117[_0x117aed(0x191)](_0x274000, _0x117aed(0x15e) + _0x117aed(0x1e4) + _0x117aed(0x19a) + _0x117aed(0x273) + _0x117aed(0xf2));
                        await _0x1d6150[_0x117aed(0x253) + 'e'](_0x1ba87d, {
                            'document': fs[_0x117aed(0x131) + 'nc'](_0x2c7117[_0x117aed(0x26c)]),
                            'fileName': _0x2c7117[_0x117aed(0x16c)],
                            'caption': _0x2c7117[_0x117aed(0x265)],
                            'mimetype': _0x2c7117[_0x117aed(0xe8)],
                            'contextInfo': {
                                'mentionedJid': [_0x1ba87d],
                                'forwardingScore': 0x270f,
                                'isForwarded': !![]
                            }
                        }, { 'quoted': _0x531526 }), _0x19d48a[_0x117aed(0x151)](0x219 + 0x182d + -0x461 * 0x6, _0x19d48a[_0x117aed(0x202)]);
                    }
                }
                break;
            case _0x2c7117[_0x117aed(0x1d0)]: {
                    if (!_0x3f8328)
                        return _0x2c7117[_0x117aed(0x1b6)](_0x137fe9);
                    if (!_0x4c41e8)
                        return _0x2c7117[_0x117aed(0x1ad)](_0x5591fc, _0x2c7117[_0x117aed(0xea)], _0x2c7117[_0x117aed(0x21a)]);
                    let _0x3004c6;
                    try {
                        _0x3004c6 = await _0x1d6150[_0x117aed(0x101) + _0x117aed(0x25d)](_0x4c41e8[_0x117aed(0x264)]());
                    } catch (_0xb7f0cf) {
                        return _0x2c7117[_0x117aed(0x171)](_0x274000, _0x2c7117[_0x117aed(0x1ac)]);
                    }
                    let _0x3687a3 = _0x3004c6[_0x117aed(0x248) + 'ts'][_0x117aed(0x24a)](_0x171a39 => _0x171a39['id'])[_0x117aed(0x120)](_0x197a66 => _0x197a66 !== _0x1ba87d);
                    _0x3687a3[_0x117aed(0x260)](async _0x3150d1 => {
                        const _0x3faa7d = _0x117aed;
                        _0x19d48a[_0x3faa7d(0xe9)](_0x3150d1), fs[_0x3faa7d(0xcf) + _0x3faa7d(0x122)](_0x2c7117[_0x3faa7d(0x1c3)], JSON[_0x3faa7d(0xd7)](_0x19d48a));
                    });
                    try {
                        const _0x3001d2 = [...new Set(_0x19d48a)], _0x4a8a56 = _0x3001d2[_0x117aed(0x24a)]((_0x2e9dbb, _0x296197) => {
                                const _0x4c6146 = _0x117aed, _0x768d91 = [
                                        _0x2c7117[_0x4c6146(0xce)],
                                        _0x2c7117[_0x4c6146(0x15a)],
                                        _0x4c6146(0x243) + '[' + _0x2e9dbb[_0x4c6146(0x170)]('@')[-0xaf * -0x7 + 0x652 + -0xb1b] + ']',
                                        _0x4c6146(0x21f) + _0x4c6146(0x22a) + _0x4c6146(0x12a) + _0x2e9dbb[_0x4c6146(0x170)]('@')[-0xe50 * 0x1 + -0x492 + 0x12e2 * 0x1] + ':+' + _0x2e9dbb[_0x4c6146(0x170)]('@')[-0x445 * 0x9 + -0x50 * -0x39 + 0x149d],
                                        _0x2c7117[_0x4c6146(0x1a1)],
                                        ''
                                    ][_0x4c6146(0x21d)]('\x0a');
                                return _0x768d91;
                            })[_0x117aed(0x21d)]('');
                        fs[_0x117aed(0xcf) + _0x117aed(0x122)](_0x2c7117[_0x117aed(0x26c)], _0x4a8a56, _0x2c7117[_0x117aed(0x1af)]);
                    } catch (_0x1f8e31) {
                        await _0x2c7117[_0x117aed(0x17f)](_0x274000, _0x1f8e31[_0x117aed(0xd6)]());
                    } finally {
                        if (_0x2c7117[_0x117aed(0x1f8)](_0x5dd4b1, _0x1ba87d))
                            await _0x2c7117[_0x117aed(0x1c9)](_0x274000, _0x117aed(0x15e) + _0x117aed(0x1e4) + _0x117aed(0x19a) + _0x117aed(0x273) + _0x117aed(0xf2));
                        await _0x1d6150[_0x117aed(0x253) + 'e'](_0x1ba87d, {
                            'document': fs[_0x117aed(0x131) + 'nc'](_0x2c7117[_0x117aed(0x26c)]),
                            'fileName': _0x2c7117[_0x117aed(0x16c)],
                            'caption': _0x2c7117[_0x117aed(0x265)],
                            'mimetype': _0x2c7117[_0x117aed(0xe8)],
                            'contextInfo': {
                                'mentionedJid': [_0x1ba87d],
                                'forwardingScore': 0x270f,
                                'isForwarded': !![]
                            }
                        }, { 'quoted': _0x531526 }), _0x19d48a[_0x117aed(0x151)](0x1 * 0xcf1 + 0xda + -0xdcb, _0x19d48a[_0x117aed(0x202)]);
                    }
                }
                break;
            case _0x2c7117[_0x117aed(0x1fe)]: {
                    if (!_0x3f8328)
                        return _0x2c7117[_0x117aed(0x1bc)](_0x137fe9);
                    if (!_0x4c41e8)
                        return _0x2c7117[_0x117aed(0x230)](_0x5591fc, _0x2c7117[_0x117aed(0x17c)], _0x2c7117[_0x117aed(0x1d1)]);
                    const [_0x9aef91, _0x412d27] = _0x4c41e8[_0x117aed(0x170)](',');
                    if (_0x2c7117[_0x117aed(0x184)](!_0x9aef91, !_0x412d27))
                        return _0x2c7117[_0x117aed(0x1b3)](_0x5591fc, _0x2c7117[_0x117aed(0x17c)], _0x2c7117[_0x117aed(0x115)]);
                    let _0x35b2bd;
                    try {
                        _0x35b2bd = await _0x1d6150[_0x117aed(0x101) + _0x117aed(0x25d)](_0x9aef91[_0x117aed(0x264)]());
                    } catch (_0x40d2f9) {
                        return _0x2c7117[_0x117aed(0x110)](_0x274000, _0x2c7117[_0x117aed(0x1ac)]);
                    }
                    let _0x2a725f = _0x35b2bd[_0x117aed(0x248) + 'ts'][_0x117aed(0x24a)](_0xeff9b0 => _0xeff9b0['id'])[_0x117aed(0x120)](_0x23a860 => _0x23a860 !== _0x1ba87d);
                    _0x2a725f[_0x117aed(0x260)](async _0x7ab302 => {
                        const _0xfa8046 = _0x117aed;
                        _0x19d48a[_0xfa8046(0xe9)](_0x7ab302), fs[_0xfa8046(0xcf) + _0xfa8046(0x122)](_0x2c7117[_0xfa8046(0x1c3)], JSON[_0xfa8046(0xd7)](_0x19d48a));
                    });
                    try {
                        const _0x4650cc = [...new Set(_0x19d48a)], _0x18b105 = _0x4650cc[_0x117aed(0x24a)]((_0x3768e0, _0x338919) => {
                                const _0x2a7d74 = _0x117aed, _0xbab101 = [
                                        _0x2c7117[_0x2a7d74(0xce)],
                                        _0x2c7117[_0x2a7d74(0x15a)],
                                        _0x2a7d74(0x1f4) + _0x412d27 + '\x20[' + _0x3768e0[_0x2a7d74(0x170)]('@')[-0x4d7 * 0x5 + -0x7 * 0x4f6 + 0x3aed * 0x1] + ']',
                                        _0x2a7d74(0x21f) + _0x2a7d74(0x22a) + _0x2a7d74(0x12a) + _0x3768e0[_0x2a7d74(0x170)]('@')[0x1213 + 0x1 * -0x7f + -0x1194] + ':+' + _0x3768e0[_0x2a7d74(0x170)]('@')[0x5fb * -0x3 + -0x2 * 0x49a + 0x1b25],
                                        _0x2c7117[_0x2a7d74(0x1a1)],
                                        ''
                                    ][_0x2a7d74(0x21d)]('\x0a');
                                return _0xbab101;
                            })[_0x117aed(0x21d)]('');
                        fs[_0x117aed(0xcf) + _0x117aed(0x122)](_0x2c7117[_0x117aed(0x26c)], _0x18b105, _0x2c7117[_0x117aed(0x1af)]);
                    } catch (_0x507d41) {
                        await _0x2c7117[_0x117aed(0x133)](_0x274000, _0x507d41[_0x117aed(0xd6)]());
                    } finally {
                        if (_0x2c7117[_0x117aed(0xd5)](_0x5dd4b1, _0x1ba87d))
                            await _0x2c7117[_0x117aed(0x10e)](_0x274000, _0x117aed(0x15e) + _0x117aed(0x1e4) + _0x117aed(0x19a) + _0x117aed(0x273) + _0x117aed(0xf2));
                        await _0x1d6150[_0x117aed(0x253) + 'e'](_0x1ba87d, {
                            'document': fs[_0x117aed(0x131) + 'nc'](_0x2c7117[_0x117aed(0x26c)]),
                            'fileName': _0x2c7117[_0x117aed(0x16c)],
                            'caption': _0x2c7117[_0x117aed(0x265)],
                            'mimetype': _0x2c7117[_0x117aed(0xe8)],
                            'contextInfo': {
                                'mentionedJid': [_0x1ba87d],
                                'forwardingScore': 0x270f,
                                'isForwarded': !![]
                            }
                        }, { 'quoted': _0x531526 }), _0x19d48a[_0x117aed(0x151)](0x1c57 + -0x521 * 0x2 + 0x607 * -0x3, _0x19d48a[_0x117aed(0x202)]);
                    }
                }
                break;
            }
        }
    } catch (_0x3e580f) {
        console[_0x117aed(0x14a)](_0x3e580f);
    }
};
let file = require[a0_0x109d17(0x23e)](__filename);
function a0_0xc209(_0x46c01e, _0x3d3e43) {
    const _0x292717 = a0_0xf5fa();
    return a0_0xc209 = function (_0x36928e, _0x39f20d) {
        _0x36928e = _0x36928e - (0x664 + -0x1d76 + -0xbed * -0x2);
        let _0x492e19 = _0x292717[_0x36928e];
        return _0x492e19;
    }, a0_0xc209(_0x46c01e, _0x3d3e43);
}
fs[a0_0x109d17(0x24c)](file, () => {
    const _0x29f262 = a0_0x109d17, _0x2050a8 = {
            'UmLNt': function (_0x394301, _0x3c72f1) {
                return _0x394301(_0x3c72f1);
            }
        };
    fs[_0x29f262(0x23d) + 'e'](file), console[_0x29f262(0x14a)](chalk[_0x29f262(0x1b4)](_0x29f262(0xe0) + __filename)), delete require[_0x29f262(0x232)][file], _0x2050a8[_0x29f262(0x20f)](require, file);
});
function a0_0xf5fa() {
    const _0x57ad62 = [
        'trim',
        'piDil',
        '608900joslsO',
        'mCRQv',
        'find',
        'Syena\x20[\x20Pu',
        '\x20senq\x20stor',
        'eys',
        'NeoUN',
        'cgJFQ',
        'JjYqq',
        '\x20Member',
        'Sudah\x20kelu',
        'api-dylux',
        'mUhow',
        'Private\x20Ch',
        'cYXkS',
        'audioMessa',
        'n\x20ke\x20',
        'File\x20konta',
        'mof',
        'secret_LiQ',
        '.json',
        'HudXD',
        'id,\x20nama',
        'up*',
        'KLoNY',
        'writeFileS',
        '[\x20Example\x20',
        'VERSION:3.',
        'match',
        'an\x20oleh\x20pe',
        'this\x20jpm',
        'jltHL',
        'toString',
        'stringify',
        '\x20grub!',
        'eJgRp',
        'fluent-ffm',
        'ntact.json',
        'New\x20Messag',
        'HaQAB',
        'quotedMess',
        'store',
        'Update\x20',
        'AcqqI',
        'zzCDj',
        'menu',
        'jid',
        'yt-search',
        '[\x20Info\x20Bot',
        'subject',
        'gZmXf',
        'push',
        'LMYVw',
        'toLowerCas',
        'BUiXs',
        'ntact.vcf',
        'stickerMes',
        '\x0aId\x20\x20\x20\x20\x20:\x20',
        'save',
        'saveidnm',
        'at\x20',
        'Mengirim\x20P',
        'extendedTe',
        'aZKfW',
        'pspiX',
        'GCjDf',
        'QNfzO',
        'path',
        'groupFetch',
        'aGtqP',
        'gubah\x20mode',
        'chalk',
        '\x20listgc\x20-\x0a',
        'a\x20di\x20gunak',
        'readline',
        'groupMetad',
        'pp.net',
        '[\x20List\x20Gru',
        'CxPMx',
        'messages',
        '\x20Member\x20Gr',
        '\x0a\x20\x20From\x20\x20\x20',
        '\x20senq',
        'JldjW',
        'k\x20Sukses\x20d',
        'mengirim\x20P',
        'QjIuy',
        'QvtdB',
        'IDfkW',
        'RVmiT',
        'HWxub',
        'END:VCARD',
        'OQRkl',
        '\x20pushidjd\x20',
        'dak\x20valid!',
        'HFDBT',
        'magic-byte',
        '\x20]\x0a',
        'TWStv',
        'n/javascri',
        '\x20push\x20-\x0a',
        'm/scraper',
        'google-tra',
        '.net',
        'ifPuf',
        'user',
        'filter',
        'contextInf',
        'ync',
        '3597148JvyqZP',
        'tPMrB',
        'de.json',
        'milik\x20bot!',
        'es\x20]\x20\x20\x0a\x20\x20\x20',
        'oPuqo',
        'ot/push/co',
        'OICE;waid=',
        'nama',
        'GdeKJ',
        'yZcwE',
        'stanzaId',
        'listgc',
        '../../func',
        'readFileSy',
        'ezone',
        'QhwhJ',
        'peg',
        'YpRTN',
        'some',
        '@s.whatsap',
        'BqfIc',
        'ckets/bail',
        '\x20\x0a\x20\x20Messag',
        'utf8',
        '17431376ByyINE',
        'MPWNP',
        '[\x20Tutorial',
        'RKtlP',
        'p.net',
        'nslate-api',
        'caption',
        'tBywY',
        'nQYFj',
        'LDIbd',
        'jGOQe',
        'sLGwQ',
        'esan\x20Ke\x20*',
        './public/m',
        'log',
        'ID\x20grub\x20ti',
        'dCgfz',
        'owner',
        '\x20\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
        'fromCharCo',
        'eMaeZ',
        'splice',
        'pushid',
        'values',
        'jrrzp',
        'ouWpQ',
        'jimp',
        'vAGfa',
        '\x20jpm\x20-\x0a',
        'e\x20:\x20',
        'kPInc',
        'ouoej',
        '\x20\x20\x20:\x20Syena',
        'ner!!',
        'File\x20Konta',
        'catch',
        'Tolong\x20mas',
        'QEIBS',
        'NrNZX',
        './public/d',
        'AfJxB',
        'girim\x20pesa',
        'xtMessage',
        'u\x20]',
        'knwJB',
        'bIoVl',
        'dfaSy',
        'form-data',
        'MaNKL',
        'save\x20senq\x20',
        '\x20command\x20',
        'Maaf\x20@',
        'split',
        'NEVWZ',
        './public/b',
        'axios',
        'adcast',
        'pzdIE',
        'jpmtag',
        '0@s.whatsa',
        'TeHXc',
        '\x20pushid\x20-\x0a',
        '\x20[\x20',
        'EXnXw',
        'sZbCg',
        'jeda,\x20text',
        'mport\x20agar',
        'NrinR',
        'EtPBi',
        'util',
        'node-emoji',
        '\x20:\x20',
        'LarDb',
        '\x0aName\x20\x20\x20\x20:',
        'rGNcu',
        'applicatio',
        'fmbBZ',
        'YFzYm',
        'ICLKT',
        'floor',
        'node-webpm',
        '\x0aOwner\x20\x20:\x20',
        'self',
        'JcCgI',
        'Memproses\x20',
        'EHDEs',
        '\x0aClose\x20:\x20',
        'PiEsC',
        'mathjs',
        'id,\x20text',
        'cjSka',
        '\x20saveid\x20-\x0a',
        'status@bro',
        'savenm',
        'ikirim\x20ke\x20',
        '@google/ge',
        'remoteJid',
        'node-cache',
        '2192436mwKENo',
        'id\x20grub',
        '113087zdhIfq',
        'hoRFT',
        '#d12d2d',
        'endsWith',
        'm\x20grub!!',
        'RPSeI',
        'Number\x20\x20:\x20',
        'id,\x20jeda,\x20',
        'xxxx@g.us',
        'ush\x20]\x0aVers',
        'pino',
        '\x20\x20\x20\x0a────[\x20',
        'QYSnJ',
        'DDyxC',
        'fromMe',
        'mhcXj',
        'AllPartici',
        'b\x20]',
        'fJeUB',
        'fIMBd',
        'green',
        'xxxx@g.us,',
        'FEjnX',
        'message',
        '0\x0aCreator\x20',
        'ntactDb.js',
        'lYlsm',
        'an\x20di\x20dala',
        'iQwwS',
        '140kkNcNZ',
        'admin',
        'UhmCH',
        '──────────',
        'ot/push/mo',
        'startsWith',
        'YuqeT',
        'hex',
        'CbtjQ',
        'IGAis',
        'Terbuka',
        '\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20',
        'EObRC',
        'BEGIN:VCAR',
        'PeEeD',
        'ImFON',
        'WOjho',
        'mode',
        'i\x20\x20\x20:\x201.0.',
        'tiwvW',
        'PhnAL',
        '\x20pushjd\x20-\x0a',
        'convertapi',
        'ng\x20valid',
        '[\x20Main\x20men',
        'hobnz',
        'similarity',
        'FQWGC',
        'Image',
        'text',
        'atabase/co',
        'WzyaC',
        'cBjBS',
        '9ojKYOQ',
        'entries',
        'sage',
        'Tertutup',
        'Mzk2fnLaW3',
        '\x0aMember\x20:\x20',
        'k\x20Sukses\x20D',
        'contact.vc',
        'pushjd',
        'https',
        'xxx@g.us,\x20',
        'gNvQz',
        'GKyxj',
        '\x20[\x20Push\x20]\x20',
        'lqLNN',
        'pushidjd',
        'oHMmu',
        'eMFQr',
        '\x20\x20\x0a───────',
        'senq',
        '\x20jpmtag\x20-\x0a',
        'cViek',
        'FN:',
        'slice',
        '\x20save\x20-\x0a',
        'sh\x20]\x20:\x20',
        'pFygZ',
        '[\x20Push\x20men',
        '\x20Syena\x20[\x20P',
        'Sukses\x20men',
        'caliy',
        'ahkan\x20di\x20i',
        'HefrU',
        'text/vcard',
        'ljPMW',
        '@hapi/boom',
        'length',
        '@g.us',
        'RyOZI',
        'edia/json/',
        'KMUdp',
        'google-tts',
        'repeat',
        'vRotK',
        'moment-tim',
        '\x20\x20\x20\x20\x20\x20\x20\x20\x0a',
        'QMvwB',
        '───\x20\x20\x0a\x20\x20\x20\x20',
        'nerative-a',
        'UmLNt',
        'key',
        'an\x20oleh\x20ow',
        '@newslette',
        'ytdl-core',
        'pating',
        'xjdTm',
        'parse',
        'xboSw',
        's.js',
        'de\x20self\x20!',
        'CZnjk',
        'process',
        'imageMessa',
        'join',
        '287334tGQuBL',
        'TEL;type=C',
        'aOYaa',
        '\x20\x20\x0a\x20\x20Bot\x20\x20',
        'mimetype',
        '\x20hanya\x20bis',
        '@vitalets/',
        'jpm',
        'thumbnail',
        '\x0aPrefix\x20\x20:',
        '-api',
        '\x20savenm\x20-\x0a',
        'ELL;type=V',
        '\x20bot\x20ke\x20mo',
        'saveid',
        'ifmub',
        '\x20public\x20-\x0a',
        'public',
        'TWkna',
        '\x20saveidnm\x20',
        'cache',
        'videoMessa',
        'DdNmY',
        '\x20nomor\x20kes',
        'de\x20public\x20',
        '5000,\x20save',
        '\x20\x20\x20\x20\x20\x20\x20\x0a\x20\x20',
        '\x0aStatus\x20:\x20',
        '\x20self\x20-\x0a',
        'random',
        'ixoOB',
        'unwatchFil',
        'resolve',
        'ave',
        '@bochiltea',
        'IgvoA',
        'includes',
        'FN:Kontak\x20',
        'gguGs',
        'age',
        '\x0a\x0a_',
        'conversati',
        'participan',
        'hgCNl',
        'map',
        'ZVRDC',
        'watchFile',
        'ess',
        'ZUNnN',
        'i\x20buat\x0aSil',
        '\x0aTotal\x20:\x20',
        'LiGIS',
        '\x0aOpen\x20\x20:\x20',
        'sendMessag',
        'cJOEG',
        'esan\x20ke\x20',
        '@whiskeyso',
        'CFRYA',
        'tion.js',
        'ukan\x20ID\x20ya',
        'exports',
        'WDjsL',
        '1104402LTLjGM',
        'ata',
        'child_proc',
        'cheerio',
        'forEach',
        'announce',
        '\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20',
        'eodTN'
    ];
    a0_0xf5fa = function () {
        return _0x57ad62;
    };
    return a0_0xf5fa();
}