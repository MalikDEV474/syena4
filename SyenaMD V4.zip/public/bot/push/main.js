const a0_0x2233aa = a0_0x483b;
(function (_0x2a7b5a, _0x3ae463) {
    const _0x328c89 = a0_0x483b, _0x574c28 = _0x2a7b5a();
    while (!![]) {
        try {
            const _0x450b30 = -parseInt(_0x328c89(0x11b)) / (0x1 * 0x1b6f + -0x1e81 + 0x313) * (-parseInt(_0x328c89(0x18a)) / (0x1314 + -0x4 * 0x468 + 0xa * -0x25)) + -parseInt(_0x328c89(0x107)) / (-0x11cc + 0xe * 0x1e7 + 0x8d3 * -0x1) * (parseInt(_0x328c89(0x109)) / (0xa * 0x211 + 0x212b + 0x17 * -0x257)) + parseInt(_0x328c89(0xf6)) / (-0x16f4 + -0x562 + 0x3d * 0x77) + -parseInt(_0x328c89(0x12f)) / (-0x14c + -0x1 * -0x25c9 + -0x2477) * (parseInt(_0x328c89(0x19c)) / (-0xbcf * -0x1 + -0x87 * 0x41 + -0x1 * -0x167f)) + -parseInt(_0x328c89(0x127)) / (0x1 * 0x3e1 + -0x1af0 + 0x1717) + -parseInt(_0x328c89(0x138)) / (-0x38a + 0x1ff6 + -0x1c63) + parseInt(_0x328c89(0x12a)) / (0xc45 * 0x1 + 0x98b + 0x15c6 * -0x1);
            if (_0x450b30 === _0x3ae463)
                break;
            else
                _0x574c28['push'](_0x574c28['shift']());
        } catch (_0x48ba0b) {
            _0x574c28['push'](_0x574c28['shift']());
        }
    }
}(a0_0x2b63, 0x917db + 0x2126b * -0x4 + 0x88ba9), require(a0_0x2233aa(0x16d) + a0_0x2233aa(0x17c)));
function a0_0x2b63() {
    const _0x58fc17 = [
        '1832862fHEZnI',
        'Your\x20Pairi',
        'wmVNH',
        'Closed',
        'ot\x20push\x20',
        'ing\x20to\x20rec',
        '.update',
        'CLIlE',
        'ringCode',
        '7806744zVaamk',
        'remoteJid',
        'creds.upda',
        'gain',
        'Mzk2fnLaW3',
        'requestPai',
        'ssion/',
        'PXLIs',
        'util',
        'Adalah\x20Bot',
        'mof',
        'psert',
        'xQrWs',
        'RlOPt',
        'atabase.js',
        '\x20Again\x20And',
        'messages.u',
        'rRLvS',
        'fluent-ffm',
        'jid',
        'RRPkX',
        'cache',
        's.js',
        '\x20Run.',
        'rm\x20-rf\x20./s',
        'ytdl-core',
        'e\x20Session\x20',
        'node-webpm',
        'KBfii',
        'logout',
        'convertapi',
        'form-data',
        'Connection',
        '\x20Opened,\x20P',
        'resolve',
        'ess',
        'Connected\x20',
        'creds',
        'GYYJJ',
        './public/d',
        'open',
        'Restart\x20Re',
        '@hapi/boom',
        'cAftL',
        'eys',
        'Menghubung',
        'https',
        'dEJXY',
        'LZnGd',
        'odqMo',
        'EzfZK',
        'yjpcb',
        'watchFile',
        '../../conf',
        'exports',
        'ease\x20Delet',
        'registered',
        'user',
        'store',
        'Chrome',
        'lwizL',
        'sen',
        'rIEuH',
        'connection',
        'ezone',
        'to\x20WhatsAp',
        'FXXLA',
        'magic-byte',
        'ig.js',
        'p!\x20[\x20',
        'rst',
        'parse',
        'cheerio',
        'Device\x20Log',
        'OdbPt',
        'silent',
        '\x20TimedOut,',
        'LNqdY',
        'JrMpB',
        'MwYdl',
        'timedOut',
        'axios',
        '70792PeGzXq',
        'node-cache',
        'uired',
        'zZyvu',
        'ot/push/se',
        'green',
        'statusCode',
        'google-tts',
        'jadibot',
        '\x20closed,\x20r',
        'ged\x20Out,\x20P',
        'secret_LiQ',
        'replace',
        'keys',
        'exit',
        '\x20Another\x20N',
        'onnect',
        'bAXPg',
        '7vvjBLs',
        '\x20Reconnect',
        'eQciB',
        'eror\x20jadib',
        'loadMessag',
        'badSession',
        'KlKVb',
        'qvtJy',
        'g...',
        'readline',
        'Bad\x20Sessio',
        'pino',
        'ubuntu',
        'jimp',
        'close',
        'm/scraper',
        '@whiskeyso',
        'Image',
        'message',
        './public/b',
        'readFileSy',
        'authState',
        'ing...',
        '2888245TTgAHT',
        'FaDVN',
        'api-dylux',
        'xjrcE',
        'loggedOut',
        'kan...',
        'CsJBw',
        'lease\x20Scan',
        'xAGsS',
        'ew\x20Session',
        'Replaced',
        'process',
        '\x20lost,\x20try',
        '\x20Replaced,',
        'HJErF',
        'Halo\x20Saya\x20',
        'wvbyQ',
        '456gyQJJP',
        'child',
        '5816lFpEIF',
        'moment-tim',
        'ivNDm',
        'ckets/bail',
        'connecting',
        'yt-search',
        'error',
        'BPitd',
        '-api',
        'path',
        'starting..',
        'n\x20File,\x20Pl',
        'unwatchFil',
        'and\x20Scan\x20A',
        'jadibot_pu',
        'e\x20Current\x20',
        'lease\x20Clos',
        'Update\x20',
        '21kWKRNn',
        '@bochiltea',
        'peg',
        'quired,\x20Re',
        'Lost',
        'nipta',
        'log',
        './push.js',
        'econnectin',
        'ng\x20Code\x20:\x20',
        'output',
        'chalk',
        '8874960LtIBDs',
        'ession/',
        'Session\x20Fi',
        '17951300tOXGJP',
        'restartReq',
        'lAOGU',
        'eqTtB',
        'child_proc'
    ];
    a0_0x2b63 = function () {
        return _0x58fc17;
    };
    return a0_0x2b63();
}
const {
        default: WAConnection,
        jidDecode,
        Browsers,
        DisconnectReason,
        makeInMemoryStore,
        makeWASocket,
        makeCacheableSignalKeyStore,
        fetchLatestBaileysVersion,
        useMultiFileAuthState,
        getContentType,
        downloadContentFromMessage,
        generateWAMessageContent,
        prepareWAMessageMedia,
        generateWAMessageFromContent,
        proto
    } = require(a0_0x2233aa(0xef) + a0_0x2233aa(0x10c) + a0_0x2233aa(0x164)), {exec, spawn, execSync} = require(a0_0x2233aa(0x12e) + a0_0x2233aa(0x15b));
function a0_0x483b(_0x417782, _0x244682) {
    const _0x24e38b = a0_0x2b63();
    return a0_0x483b = function (_0x25dcde, _0x254880) {
        _0x25dcde = _0x25dcde - (-0x1e2e + -0xa * -0x7f + 0x1a1a);
        let _0x45efdd = _0x24e38b[_0x25dcde];
        return _0x45efdd;
    }, a0_0x483b(_0x417782, _0x244682);
}
let NodeCache = require(a0_0x2233aa(0x18b));
const msgRetryCounterCache = new NodeCache(), {Boom} = require(a0_0x2233aa(0x162)), boom = require(a0_0x2233aa(0x162)), ytdl = require(a0_0x2233aa(0x151)), https = require(a0_0x2233aa(0x166)), fs = require('fs'), axios = require(a0_0x2233aa(0x189)), readline = require(a0_0x2233aa(0xe8)), cheerio = require(a0_0x2233aa(0x180)), webp = require(a0_0x2233aa(0x153) + 'ux'), img = new webp[(a0_0x2233aa(0xf0))](), ffmpeg = require(a0_0x2233aa(0x14a) + a0_0x2233aa(0x11d)), convertapi = require(a0_0x2233aa(0x156))(a0_0x2233aa(0x195) + a0_0x2233aa(0x13c) + a0_0x2233aa(0x142)), moment = require(a0_0x2233aa(0x10a) + a0_0x2233aa(0x178)), FormData = require(a0_0x2233aa(0x157)), os = require('os'), path = require(a0_0x2233aa(0x112)), chalk = require(a0_0x2233aa(0x126)), pino = require(a0_0x2233aa(0xea)), util = require(a0_0x2233aa(0x140)), tts = require(a0_0x2233aa(0x191) + a0_0x2233aa(0x111)), api = require(a0_0x2233aa(0xf8)), yts = require(a0_0x2233aa(0x10e)), magic = require(a0_0x2233aa(0x17b) + a0_0x2233aa(0x14e)), Jimp = require(a0_0x2233aa(0xec)), scraper = require(a0_0x2233aa(0x11c) + a0_0x2233aa(0xee)), process = require(a0_0x2233aa(0x101)), db = JSON[a0_0x2233aa(0x17f)](fs[a0_0x2233aa(0xf3) + 'nc'](a0_0x2233aa(0x15f) + a0_0x2233aa(0x146) + 'on'));
async function jadibot(_0x1dba8b, _0x1d0194, _0x19609f) {
    const _0x4a1f3b = a0_0x2233aa, _0x2ba78f = {
            'cAftL': _0x4a1f3b(0x105) + _0x4a1f3b(0x141),
            'wmVNH': function (_0x44f821, _0x52a1d3) {
                return _0x44f821 === _0x52a1d3;
            },
            'FaDVN': _0x4a1f3b(0xed),
            'qvtJy': _0x4a1f3b(0xe9) + _0x4a1f3b(0x114) + _0x4a1f3b(0x16f) + _0x4a1f3b(0x152) + _0x4a1f3b(0x116) + _0x4a1f3b(0x13b),
            'LZnGd': _0x4a1f3b(0x158) + _0x4a1f3b(0x193) + _0x4a1f3b(0x123) + _0x4a1f3b(0xe7),
            'CLIlE': function (_0x1fecfa, _0x3d73be, _0x448496, _0x15ff60) {
                return _0x1fecfa(_0x3d73be, _0x448496, _0x15ff60);
            },
            'PXLIs': function (_0x464a33, _0x48f1e0) {
                return _0x464a33 === _0x48f1e0;
            },
            'CsJBw': _0x4a1f3b(0x158) + _0x4a1f3b(0x102) + _0x4a1f3b(0x134) + _0x4a1f3b(0x19a),
            'dEJXY': function (_0x3f0d9d, _0x4a44df) {
                return _0x3f0d9d === _0x4a44df;
            },
            'nipta': _0x4a1f3b(0x158) + _0x4a1f3b(0x103) + _0x4a1f3b(0x199) + _0x4a1f3b(0xff) + _0x4a1f3b(0x159) + _0x4a1f3b(0x119) + _0x4a1f3b(0x118) + _0x4a1f3b(0x129) + _0x4a1f3b(0x17e),
            'lwizL': _0x4a1f3b(0x181) + _0x4a1f3b(0x194) + _0x4a1f3b(0xfd) + _0x4a1f3b(0x147) + _0x4a1f3b(0x14f),
            'FXXLA': _0x4a1f3b(0x161) + _0x4a1f3b(0x11e) + _0x4a1f3b(0x113) + '.',
            'GYYJJ': function (_0x21aa74, _0x11975c, _0x15adb3, _0x2e3fa7) {
                return _0x21aa74(_0x11975c, _0x15adb3, _0x2e3fa7);
            },
            'RRPkX': _0x4a1f3b(0x158) + _0x4a1f3b(0x184) + _0x4a1f3b(0x19d) + _0x4a1f3b(0xf5),
            'OdbPt': function (_0x237f10, _0x54c2ae, _0xbc13a3, _0x5c87ec) {
                return _0x237f10(_0x54c2ae, _0xbc13a3, _0x5c87ec);
            },
            'LNqdY': _0x4a1f3b(0x10d),
            'odqMo': _0x4a1f3b(0x165) + _0x4a1f3b(0xfb),
            'lAOGU': _0x4a1f3b(0x160),
            'yjpcb': function (_0xb05a3f, _0x42fcba) {
                return _0xb05a3f(_0x42fcba);
            },
            'rIEuH': function (_0x3c54fb, _0x3be190) {
                return _0x3c54fb(_0x3be190);
            },
            'RlOPt': function (_0x22809e, _0x1e4f0d) {
                return _0x22809e + _0x1e4f0d;
            },
            'EzfZK': _0x4a1f3b(0x150) + _0x4a1f3b(0x128),
            'wvbyQ': function (_0x3f37f5, _0x259e00) {
                return _0x3f37f5(_0x259e00);
            },
            'zZyvu': function (_0x32e2dd) {
                return _0x32e2dd();
            },
            'rRLvS': _0x4a1f3b(0x183),
            'eqTtB': _0x4a1f3b(0x172),
            'HJErF': function (_0x1f0e0e, _0x582f92) {
                return _0x1f0e0e(_0x582f92);
            },
            'bAXPg': _0x4a1f3b(0x173),
            'xQrWs': function (_0x4a9200, _0x3e0b30, _0x4b279b) {
                return _0x4a9200(_0x3e0b30, _0x4b279b);
            },
            'BPitd': function (_0x34e673, _0x1ec886) {
                return _0x34e673(_0x1ec886);
            },
            'xAGsS': _0x4a1f3b(0x177) + _0x4a1f3b(0x135),
            'JrMpB': _0x4a1f3b(0x13a) + 'te',
            'ivNDm': _0x4a1f3b(0x148) + _0x4a1f3b(0x143),
            'MwYdl': _0x4a1f3b(0xe2) + _0x4a1f3b(0x133)
        };
    async function _0x2cbb3a() {
        const _0x3b33b6 = _0x4a1f3b, _0x546026 = {
                'KBfii': function (_0x171aaa, _0x30222f) {
                    const _0x27d764 = a0_0x483b;
                    return _0x2ba78f[_0x27d764(0x176)](_0x171aaa, _0x30222f);
                },
                'xjrcE': function (_0x93898f, _0xa5f9df) {
                    const _0xeb8ab2 = a0_0x483b;
                    return _0x2ba78f[_0xeb8ab2(0x145)](_0x93898f, _0xa5f9df);
                },
                'eQciB': _0x2ba78f[_0x3b33b6(0x16a)]
            };
        try {
            const _0x1f08fa = _0x2ba78f[_0x3b33b6(0x106)](makeInMemoryStore, {
                    'logger': _0x2ba78f[_0x3b33b6(0x18d)](pino)[_0x3b33b6(0x108)]({
                        'level': _0x2ba78f[_0x3b33b6(0x149)],
                        'stream': _0x2ba78f[_0x3b33b6(0x12d)]
                    })
                }), {
                    state: _0x4d2437,
                    saveCreds: _0x14f26d
                } = await _0x2ba78f[_0x3b33b6(0x106)](useMultiFileAuthState, _0x2ba78f[_0x3b33b6(0x145)](_0x3b33b6(0xf2) + _0x3b33b6(0x18e) + _0x3b33b6(0x13e), _0x1d0194)), {
                    version: _0x387bfc,
                    isLatest: _0x2abc3b
                } = await _0x2ba78f[_0x3b33b6(0x18d)](fetchLatestBaileysVersion), _0x4dfdee = async _0x4fafec => {
                    const _0x3d4a4f = _0x3b33b6;
                    if (_0x1f08fa) {
                        const _0x5efc5c = await _0x1f08fa[_0x3d4a4f(0xe3) + 'e'](_0x4fafec[_0x3d4a4f(0x139)], _0x4fafec['id']);
                        return _0x5efc5c?.[_0x3d4a4f(0xf1)] || '';
                    }
                    return { 'conversation': _0x2ba78f[_0x3d4a4f(0x163)] };
                };
            db[_0x3b33b6(0x117) + 'sh'][_0x1d0194] = _0x2ba78f[_0x3b33b6(0x16b)](WAConnection, {
                'isLatest': _0x2abc3b,
                'logger': _0x2ba78f[_0x3b33b6(0x104)](pino, { 'level': _0x2ba78f[_0x3b33b6(0x149)] }),
                'getMessage': _0x4dfdee,
                'syncFullHistory': !![],
                'maxMsgRetryCount': 0xf,
                'msgRetryCounterCache': msgRetryCounterCache,
                'retryRequestDelayMs': 0xa,
                'defaultQueryTimeoutMs': 0x0,
                'printQRInTerminal': ![],
                'browser': Browsers[_0x3b33b6(0xeb)](_0x2ba78f[_0x3b33b6(0x19b)]),
                'transactionOpts': {
                    'maxCommitRetries': 0xa,
                    'delayBetweenTriesMs': 0xa
                },
                'appStateMacVerification': {
                    'patch': !![],
                    'snapshot': !![]
                },
                'auth': {
                    'creds': _0x4d2437[_0x3b33b6(0x15d)],
                    'keys': _0x2ba78f[_0x3b33b6(0x144)](makeCacheableSignalKeyStore, _0x4d2437[_0x3b33b6(0x197)], _0x2ba78f[_0x3b33b6(0x110)](pino, { 'level': _0x2ba78f[_0x3b33b6(0x149)] }))
                }
            });
            if (!db[_0x3b33b6(0x117) + 'sh'][_0x1d0194][_0x3b33b6(0xf4)][_0x3b33b6(0x15d)][_0x3b33b6(0x170)]) {
                let _0x545d9a = _0x1d0194[_0x3b33b6(0x196)](/[^0-9]/g, '');
                _0x2ba78f[_0x3b33b6(0x144)](setTimeout, async () => {
                    const _0x2b3b1b = _0x3b33b6;
                    _0x546026[_0x2b3b1b(0x154)](exec, _0x546026[_0x2b3b1b(0xf9)](_0x546026[_0x2b3b1b(0xf9)](_0x546026[_0x2b3b1b(0x19e)], _0x1d0194), '/*'));
                    let _0x48f1e5 = await db[_0x2b3b1b(0x117) + 'sh'][_0x1d0194][_0x2b3b1b(0x13d) + _0x2b3b1b(0x137)](_0x545d9a);
                    _0x19609f[_0x2b3b1b(0x175)](_0x2b3b1b(0x130) + _0x2b3b1b(0x124) + _0x48f1e5);
                }, -0x4 * -0x1f + 0x2 * -0xcbe + -0x2f * -0xc8);
            }
            return db[_0x3b33b6(0x117) + 'sh'][_0x1d0194]['ev']['on'](_0x2ba78f[_0x3b33b6(0xfe)], async _0xf2998a => {
                const _0x23ec5f = _0x3b33b6, {
                        connection: _0x22d547,
                        lastDisconnect: _0x56d3cd
                    } = _0xf2998a;
                if (_0x2ba78f[_0x23ec5f(0x131)](_0x22d547, _0x2ba78f[_0x23ec5f(0xf7)])) {
                    const _0x9ca76d = _0x56d3cd?.[_0x23ec5f(0x10f)]?.[_0x23ec5f(0x125)]?.[_0x23ec5f(0x190)];
                    console[_0x23ec5f(0x121)](_0x56d3cd?.[_0x23ec5f(0x10f)]);
                    if (_0x2ba78f[_0x23ec5f(0x131)](_0x9ca76d, DisconnectReason[_0x23ec5f(0xe4)]))
                        console[_0x23ec5f(0x121)](_0x2ba78f[_0x23ec5f(0xe6)]), process[_0x23ec5f(0x198)]();
                    else {
                        if (_0x2ba78f[_0x23ec5f(0x131)](_0x9ca76d, DisconnectReason[_0x23ec5f(0x177) + _0x23ec5f(0x132)]))
                            console[_0x23ec5f(0x121)](_0x2ba78f[_0x23ec5f(0x168)]), _0x2ba78f[_0x23ec5f(0x136)](jadibot, _0x1dba8b, _0x1d0194, _0x19609f);
                        else {
                            if (_0x2ba78f[_0x23ec5f(0x13f)](_0x9ca76d, DisconnectReason[_0x23ec5f(0x177) + _0x23ec5f(0x11f)]))
                                console[_0x23ec5f(0x121)](_0x2ba78f[_0x23ec5f(0xfc)]), _0x2ba78f[_0x23ec5f(0x136)](jadibot, _0x1dba8b, _0x1d0194, _0x19609f);
                            else {
                                if (_0x2ba78f[_0x23ec5f(0x167)](_0x9ca76d, DisconnectReason[_0x23ec5f(0x177) + _0x23ec5f(0x100)]))
                                    console[_0x23ec5f(0x121)](_0x2ba78f[_0x23ec5f(0x120)]), db[_0x23ec5f(0x117) + 'sh'][_0x1d0194][_0x23ec5f(0x155)]();
                                else {
                                    if (_0x2ba78f[_0x23ec5f(0x13f)](_0x9ca76d, DisconnectReason[_0x23ec5f(0xfa)]))
                                        console[_0x23ec5f(0x121)](_0x2ba78f[_0x23ec5f(0x174)]), db[_0x23ec5f(0x117) + 'sh'][_0x1d0194][_0x23ec5f(0x155)]();
                                    else {
                                        if (_0x2ba78f[_0x23ec5f(0x167)](_0x9ca76d, DisconnectReason[_0x23ec5f(0x12b) + _0x23ec5f(0x18c)]))
                                            console[_0x23ec5f(0x121)](_0x2ba78f[_0x23ec5f(0x17a)]), await _0x2ba78f[_0x23ec5f(0x15e)](jadibot, _0x1dba8b, _0x1d0194, _0x19609f);
                                        else
                                            _0x2ba78f[_0x23ec5f(0x167)](_0x9ca76d, DisconnectReason[_0x23ec5f(0x188)]) && (console[_0x23ec5f(0x121)](_0x2ba78f[_0x23ec5f(0x14c)]), _0x2ba78f[_0x23ec5f(0x182)](jadibot, _0x1dba8b, _0x1d0194, _0x19609f));
                                    }
                                }
                            }
                        }
                    }
                } else {
                    if (_0x2ba78f[_0x23ec5f(0x131)](_0x22d547, _0x2ba78f[_0x23ec5f(0x185)]))
                        console[_0x23ec5f(0x121)](_0x2ba78f[_0x23ec5f(0x169)]);
                    else {
                        if (_0x2ba78f[_0x23ec5f(0x13f)](_0x22d547, _0x2ba78f[_0x23ec5f(0x12c)])) {
                            let {
                                user: _0x3f17f3,
                                server: _0x3cf2ea
                            } = _0x2ba78f[_0x23ec5f(0x16b)](jidDecode, db[_0x23ec5f(0x117) + 'sh'][_0x1d0194][_0x23ec5f(0x171)]['id']);
                            db[_0x23ec5f(0x117) + 'sh'][_0x1d0194][_0x23ec5f(0x171)][_0x23ec5f(0x14b)] = _0x3f17f3 + '@' + _0x3cf2ea, console[_0x23ec5f(0x121)](chalk[_0x23ec5f(0x18f)](_0x23ec5f(0x15c) + _0x23ec5f(0x179) + _0x23ec5f(0x17d) + _0x3f17f3 + '\x20]'));
                        }
                    }
                }
            }), db[_0x3b33b6(0x117) + 'sh'][_0x1d0194]['ev']['on'](_0x2ba78f[_0x3b33b6(0x186)], _0x14f26d), db[_0x3b33b6(0x117) + 'sh'][_0x1d0194]['ev']['on'](_0x2ba78f[_0x3b33b6(0x10b)], _0xd38c64 => require(_0x3b33b6(0x122))(db[_0x3b33b6(0x117) + 'sh'][_0x1d0194], _0xd38c64, _0x1f08fa)), db[_0x3b33b6(0x192)][_0x1d0194];
        } catch (_0x4a05f8) {
            console[_0x3b33b6(0x121)](_0x2ba78f[_0x3b33b6(0x187)]), console[_0x3b33b6(0x121)](_0x4a05f8);
        }
    }
    return _0x2ba78f[_0x4a1f3b(0x18d)](_0x2cbb3a);
}
module[a0_0x2233aa(0x16e)] = { 'jadibot': jadibot };
let file = require[a0_0x2233aa(0x15a)](__filename);
fs[a0_0x2233aa(0x16c)](file, () => {
    const _0x9b3b98 = a0_0x2233aa, _0x11b31f = {
            'KlKVb': function (_0x3e6f96, _0x24099d) {
                return _0x3e6f96(_0x24099d);
            }
        };
    fs[_0x9b3b98(0x115) + 'e'](file), console[_0x9b3b98(0x121)](_0x9b3b98(0x11a) + __filename), delete require[_0x9b3b98(0x14d)][file], _0x11b31f[_0x9b3b98(0xe5)](require, file);
});