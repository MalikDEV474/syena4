const a0_0x567913 = a0_0x46bd;
function a0_0x46bd(_0x3d7179, _0x46efcb) {
    const _0x5a932c = a0_0x2451();
    return a0_0x46bd = function (_0x1beef8, _0x4b2f8a) {
        _0x1beef8 = _0x1beef8 - (0xd01 + -0xa21 + 0x14 * -0xe);
        let _0x393305 = _0x5a932c[_0x1beef8];
        return _0x393305;
    }, a0_0x46bd(_0x3d7179, _0x46efcb);
}
(function (_0x500172, _0x3ae96e) {
    const _0x21000c = a0_0x46bd, _0x2edaf6 = _0x500172();
    while (!![]) {
        try {
            const _0x60126 = parseInt(_0x21000c(0x1d6)) / (-0x1e * -0x12c + 0xd68 + 0x308f * -0x1) * (parseInt(_0x21000c(0x1e3)) / (-0x1 * -0x1542 + -0x1 * 0x175 + -0x3 * 0x699)) + parseInt(_0x21000c(0x1ec)) / (-0xad0 + 0x1fb3 * -0x1 + 0x2a86) * (-parseInt(_0x21000c(0x1f1)) / (-0x1 * -0x7ac + -0x205b + 0x18b3)) + parseInt(_0x21000c(0x1d4)) / (-0x4b8 * -0x3 + 0x83 + -0x2ee * 0x5) * (-parseInt(_0x21000c(0x1d0)) / (0x890 + -0x1c33 + 0x13a9)) + -parseInt(_0x21000c(0x1e7)) / (0x1a96 * -0x1 + -0x169 * -0x13 + -0x17 * 0x2) * (-parseInt(_0x21000c(0x1fd)) / (0x2f * -0xd + -0x26c1 + 0x292c)) + parseInt(_0x21000c(0x1d3)) / (-0x1a6c + 0x15f7 + 0x1 * 0x47e) + -parseInt(_0x21000c(0x1f3)) / (-0x1de4 + 0x1 * -0x44a + 0x2238) + parseInt(_0x21000c(0x1d5)) / (-0x1772 + 0xca1 * 0x3 + -0xe66);
            if (_0x60126 === _0x3ae96e)
                break;
            else
                _0x2edaf6['push'](_0x2edaf6['shift']());
        } catch (_0x30d9fe) {
            _0x2edaf6['push'](_0x2edaf6['shift']());
        }
    }
}(a0_0x2451, -0x87a21 + -0x9bc3a + 0x213565));
const fs = require('fs'), chalk = require(a0_0x567913(0x1fc));
global[a0_0x567913(0x1e2)] = a0_0x567913(0x1fa), global[a0_0x567913(0x1ea)] = a0_0x567913(0x1cc), global[a0_0x567913(0x1e5)] = -0x2 * 0x40044848648 + -0x6b6a207f6da + 0x146e15b45788, global[a0_0x567913(0x1c9)] = a0_0x567913(0x1f9) + a0_0x567913(0x1dc) + a0_0x567913(0x1eb), global[a0_0x567913(0x1ff)] = a0_0x567913(0x1ee) + a0_0x567913(0x1fb) + a0_0x567913(0x1d8), global['b'] = '`', global['b3'] = a0_0x567913(0x1ed), global[a0_0x567913(0x1da)] = a0_0x567913(0x1f2), global[a0_0x567913(0x1f8)] = a0_0x567913(0x1d9) + a0_0x567913(0x1e9) + a0_0x567913(0x1e8), global[a0_0x567913(0x1ef)] = a0_0x567913(0x1c8) + a0_0x567913(0x1d2) + 'D', global[a0_0x567913(0x1ca)] = a0_0x567913(0x1de) + a0_0x567913(0x1e1) + a0_0x567913(0x1dd) + a0_0x567913(0x1cd) + a0_0x567913(0x1d1) + a0_0x567913(0x1ce), global[a0_0x567913(0x200)] = '15', global[a0_0x567913(0x1f5)] = '1', global[a0_0x567913(0x1df) + 'g'] = '', global[a0_0x567913(0x1f6)] = {
    'kali': '❌',
    'ceklis': '✅',
    'hijau': '🟢',
    'merah': '🔴',
    'jam': '⏱️',
    'seeds': '🌱',
    'tree1': '🌲',
    'tree2': '🌳',
    'tree3': '🌴',
    'kail': '🪝',
    'umpan': '🪱',
    'joran': '🎣',
    'shop': {
        'fish': {
            'umpan': {
                'emoji': '🪱',
                'harga': 0x2,
                'type': a0_0x567913(0x1fe),
                'count': 0x1
            },
            'joran': {
                'emoji': '🎣',
                'harga': 0xf,
                'type': a0_0x567913(0x1fe),
                'count': 0x64
            },
            'kepiting': {
                'emoji': '🦀',
                'harga': 0xa,
                'type': a0_0x567913(0x1cf)
            },
            'lobster': {
                'emoji': '🦞',
                'harga': 0xf,
                'type': a0_0x567913(0x1cf)
            },
            'udang': {
                'emoji': '🦐',
                'harga': 0x8,
                'type': a0_0x567913(0x1cf)
            },
            'cumi': {
                'emoji': '🦑',
                'harga': 0x7,
                'type': a0_0x567913(0x1cf)
            },
            'gurita': {
                'emoji': '🐙',
                'harga': 0xc,
                'type': a0_0x567913(0x1cf)
            },
            'buntal': {
                'emoji': '🐡',
                'harga': 0x6,
                'type': a0_0x567913(0x1cf)
            },
            'dory': {
                'emoji': '🐠',
                'harga': 0x9,
                'type': a0_0x567913(0x1cf)
            },
            'orca': {
                'emoji': '🐳',
                'harga': 0xe,
                'type': a0_0x567913(0x1cf)
            },
            'lumba': {
                'emoji': '🐬',
                'harga': 0xd,
                'type': a0_0x567913(0x1cf)
            },
            'paus': {
                'emoji': '🐋',
                'harga': 0xb,
                'type': a0_0x567913(0x1cf)
            },
            'hiu': {
                'emoji': '🦈',
                'harga': 0x5,
                'type': a0_0x567913(0x1cf)
            }
        },
        'buah': {
            'aple': {
                'emoji': '🍏',
                'harga': 0x7,
                'type': a0_0x567913(0x1d7)
            },
            'pir': {
                'emoji': '🍐',
                'harga': 0x6,
                'type': a0_0x567913(0x1d7)
            },
            'jeruk': {
                'emoji': '🍊',
                'harga': 0x5,
                'type': a0_0x567913(0x1d7)
            },
            'lemon': {
                'emoji': '🍋',
                'harga': 0x4,
                'type': a0_0x567913(0x1d7)
            },
            'pisang': {
                'emoji': '🍌',
                'harga': 0x3,
                'type': a0_0x567913(0x1d7)
            },
            'semangka': {
                'emoji': '🍉',
                'harga': 0xa
            },
            'anggur': {
                'emoji': '🍇',
                'harga': 0x9,
                'type': a0_0x567913(0x1d7)
            },
            'stroberi': {
                'emoji': '🍓',
                'harga': 0x8,
                'type': a0_0x567913(0x1d7)
            },
            'blueberry': {
                'emoji': '🫐',
                'harga': 0x7,
                'type': a0_0x567913(0x1d7)
            },
            'melon': {
                'emoji': '🍈',
                'harga': 0x6,
                'type': a0_0x567913(0x1d7)
            },
            'ceri': {
                'emoji': '🍒',
                'harga': 0x9,
                'type': a0_0x567913(0x1d7)
            },
            'mangga': {
                'emoji': '🥭',
                'harga': 0x7,
                'type': a0_0x567913(0x1d7)
            },
            'nanas': {
                'emoji': '🍍',
                'harga': 0x8,
                'type': a0_0x567913(0x1d7)
            },
            'kelapa': {
                'emoji': '🥥',
                'harga': 0x6,
                'type': a0_0x567913(0x1d7)
            },
            'kiwi': {
                'emoji': '🥝',
                'harga': 0x7,
                'type': a0_0x567913(0x1d7)
            },
            'tomat': {
                'emoji': '🍅',
                'harga': 0x4,
                'type': a0_0x567913(0x1d7)
            },
            'alpukat': {
                'emoji': '🥑',
                'harga': 0x5,
                'type': a0_0x567913(0x1d7)
            }
        }
    }
}, global[a0_0x567913(0x1f0)] = /(?:youtube\.com\/\S*(?:(?:\/e(?:mbed))?\/|watch\?(?:\S*?&?v\=))|youtu\.be\/)([a-zA-Z0-9_-]{6,11})/;
function a0_0x2451() {
    const _0x4d5a1b = [
        'emoji',
        'resolve',
        'header',
        '1203633652',
        'SyenaMD',
        '.me/628317',
        'chalk',
        '16uNPxGv',
        'items',
        'linkwa',
        'egg',
        '>\x20©\x20copyri',
        'sletter',
        'linkch',
        'green',
        'SenQ\x20Tobio',
        '029Vb1X5B1',
        'u3H',
        'kolam',
        '1698PFCGvF',
        'CBtx7aiTdA',
        'ght\x20SyenaM',
        '3869379tjrRCJ',
        '31355vqTNFP',
        '4551591aDjGOv',
        '13973zRyBTY',
        'farm',
        '8759205',
        '`[\x20CREATED',
        'version',
        'OejVK',
        '10142707@n',
        '/channel/0',
        'https://wh',
        'codePairin',
        'unwatchFil',
        'atsapp.com',
        'name',
        '254VGuaum',
        'cache',
        'contact',
        'watchFile',
        '1611463giNAae',
        'OBIO\x20]`',
        '\x20BY\x20SENQ\x20T',
        'author',
        'ewsletter',
        '24PnnDyF',
        '```',
        'https://wa',
        'footer',
        'ytUrl',
        '1644mszADz',
        '4.0.0',
        '3179260dmezml',
        'log',
        'loc'
    ];
    a0_0x2451 = function () {
        return _0x4d5a1b;
    };
    return a0_0x2451();
}
let file = require[a0_0x567913(0x1f7)](__filename);
fs[a0_0x567913(0x1e6)](file, () => {
    const _0x1f73be = a0_0x567913, _0x2ed8ea = {
            'OejVK': function (_0x3cc9a8, _0x53df32) {
                return _0x3cc9a8(_0x53df32);
            }
        };
    fs[_0x1f73be(0x1e0) + 'e'](file), console[_0x1f73be(0x1f4)](chalk[_0x1f73be(0x1cb)](__filename)), delete require[_0x1f73be(0x1e4)][file], _0x2ed8ea[_0x1f73be(0x1db)](require, file);
});